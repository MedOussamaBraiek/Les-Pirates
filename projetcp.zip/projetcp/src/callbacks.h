#include <gtk/gtk.h>


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_supprimer_capt_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modifier_capt_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajouter_capt_clicked                (GtkWidget       *button,
                                        gpointer         user_data);


void
on_confirmer2_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourner2_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);


void
on_rechercher_capt_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourner5_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_confirmer5_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourner6_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton8_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton9_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton10_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton11_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton12_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_confirmer6_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourner7_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourner8_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_refrecher_capt_clicked              (GtkWidget       *button,
                                        gpointer         user_data);




