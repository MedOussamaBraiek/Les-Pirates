#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include<string.h>
#include<stdlib.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "capteur.h"


int j,k,l,w;

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{


	GtkTreeIter iter;
	gchar* marque ;
	gchar* type;
	gchar* valeur;	
	gchar* id;
	
	capteur capt;
	
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	
	if(gtk_tree_model_get_iter(model,&iter,path)){
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&marque,1,&id,2,&type,3,&valeur,-1);
		strcpy(capt.marque,marque);
		strcpy(capt.id,id);
		strcpy(capt.type,type);
		strcpy(capt.valeur,valeur);
		
		supp_capt(capt);
		
		aff_capt(treeview);
		
	
	}

}

void
on_supprimer_capt_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{


    GtkWidget *fenetre_afficher,*treeview1;
	GtkTreeSelection *selection ;
	GtkTreeModel *model;
	GtkTreeIter iter;
	
	gchar* marque ;
	gchar* type;
	gchar* valeur;	
	gchar* id;
	
	capteur capt;

	fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
	treeview1=lookup_widget(fenetre_afficher,"treeview1");
	selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview1));
	
	if(gtk_tree_selection_get_selected(selection,&model,&iter)) {
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&marque,1,&id,2,&type,3,&valeur,-1);
		strcpy(capt.marque,marque);
		strcpy(capt.id,id);
		strcpy(capt.type,type);
		strcpy(capt.valeur,valeur);
		fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
		gtk_widget_destroy(fenetre_afficher);
		fenetre_afficher=create_fenetre_afficher();
		gtk_widget_show(fenetre_afficher);
		treeview1=lookup_widget(fenetre_afficher,"treeview1");
		supp_capt(capt);
		aff_capt(treeview1);
		
	
	}

}


void
on_modifier_capt_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{

	GtkWidget *fenetre_afficher,*fenetre_modifier,*treeview1;
	GtkTreeSelection *selection ;
	GtkTreeModel *model;
	GtkTreeIter iter;
	GtkWidget *input2,*input4,*JOUR,*MOIS,*ANNEE,*marquecp,*typecp;
	GtkToggleButton *togglebutton;	

	gchar* marque ;
	gchar* type;
	gchar* valeur;	
	gchar* id;
	int jouri,moisi,anneei;

	capteur capt_modif;


        fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
	treeview1=lookup_widget(fenetre_afficher,"treeview1");
	selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview1));

	if(gtk_tree_selection_get_selected(selection,&model,&iter)) {
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&marque,1,&id,2,&type,3,&valeur,-1);
		strcpy(capt_modif.marque,marque);
		strcpy(capt_modif.id,id);
		strcpy(capt_modif.type,type);
		strcpy(capt_modif.valeur,valeur);
	}


	spin_button_get_val(capt_modif,&jouri,&moisi,&anneei);

	capt_modif.date_capt.jour=jouri;
	capt_modif.date_capt.mois=moisi;
	capt_modif.date_capt.annee=anneei;



	gtk_widget_destroy(fenetre_afficher);
	fenetre_modifier=create_fenetre_modifier();
	gtk_widget_show(fenetre_modifier);

	input2=lookup_widget(fenetre_modifier,"id_modf1");
	input4=lookup_widget(fenetre_modifier,"v_modf1");
	
	JOUR=lookup_widget(fenetre_modifier,"spinbutton1");
	MOIS=lookup_widget(fenetre_modifier,"spinbutton2");
	ANNEE=lookup_widget(fenetre_modifier,"spinbutton3");

	if(j==1){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(togglebutton),TRUE);
	}
	else if(j==2){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(togglebutton),TRUE);
	}
	else if(j==3){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(togglebutton),TRUE);
	}
	
	gtk_entry_set_text(GTK_ENTRY(input2),capt_modif.id);
	if(k==1){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(togglebutton),TRUE);
	}
	else if(k==2){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(togglebutton),TRUE);
	}
	else if(k==3){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(togglebutton),TRUE);
	}
	gtk_entry_set_text(GTK_ENTRY(input4),capt_modif.valeur);
	
	gtk_spin_button_set_value(JOUR,capt_modif.date_capt.jour);
	gtk_spin_button_set_value(MOIS,capt_modif.date_capt.mois);
	gtk_spin_button_set_value(ANNEE,capt_modif.date_capt.annee);
	
	marquecp=lookup_widget(fenetre_modifier,"labelm");
	typecp=lookup_widget(fenetre_modifier,"labelt");



	if(strcmp(marque,"A")==0){

		GdkColor color;
		gdk_color_parse("gold",&color);
		gtk_widget_modify_fg(marquecp,GTK_STATE_NORMAL,&color);
		gtk_label_set_text(GTK_LABEL(marquecp),"(Marque A)");
	}
	
	if(strcmp(marque,"B")==0){

		GdkColor color;
		gdk_color_parse("gold",&color);
		gtk_widget_modify_fg(marquecp,GTK_STATE_NORMAL,&color);
		gtk_label_set_text(GTK_LABEL(marquecp),"(Marque B)");
	}
	
	if(strcmp(marque,"C")==0){

		GdkColor color;
		gdk_color_parse("gold",&color);
		gtk_widget_modify_fg(marquecp,GTK_STATE_NORMAL,&color);
		gtk_label_set_text(GTK_LABEL(marquecp),"(Marque C)");
	}

	if(strcmp(type,"Temp")==0){

		GdkColor color;
		gdk_color_parse("gold",&color);
		gtk_widget_modify_fg(typecp,GTK_STATE_NORMAL,&color);
		gtk_label_set_text(GTK_LABEL(typecp),"(Temperature)");
	}

	if(strcmp(type,"Humd")==0){

		GdkColor color;
		gdk_color_parse("gold",&color);
		gtk_widget_modify_fg(typecp,GTK_STATE_NORMAL,&color);
		gtk_label_set_text(GTK_LABEL(typecp),"(Humidite)");
	}

	if(strcmp(type,"Niv")==0){

		GdkColor color;
		gdk_color_parse("gold",&color);
		gtk_widget_modify_fg(typecp,GTK_STATE_NORMAL,&color);
		gtk_label_set_text(GTK_LABEL(typecp),"(Niveau)");
	}

}


void
on_ajouter_capt_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{



	GtkWidget *fenetre_ajouter1,*fenetre_afficher;
	fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
	gtk_widget_destroy(fenetre_afficher);
	fenetre_ajouter1=create_fenetre_ajouter1();
	gtk_widget_show(fenetre_ajouter1);
	
}







void
on_confirmer2_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{

	capteur capt;
	GtkWidget *fenetre_supprimer;
	GtkWidget *fenetre_afficher;
	GtkWidget *treeview1;
	GtkWidget *input1;


	
	fenetre_supprimer=lookup_widget(objet,"fenetre_supprimer");
	

	input1=lookup_widget(objet,"id_supp");

	strcpy(capt.id,gtk_entry_get_text(GTK_ENTRY(input1)));

	supp_capt(capt);

	gtk_widget_destroy(fenetre_supprimer);
	fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
	fenetre_afficher=create_fenetre_afficher();
		
	
	gtk_widget_show(fenetre_afficher);
	
	treeview1=lookup_widget(fenetre_afficher,"treeview1");
	
	aff_capt(treeview1);		


}


void
on_retourner2_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{

	GtkWidget *fenetre_supprimer,*fenetre_afficher,*treeview1;

	fenetre_supprimer=lookup_widget(objet,"fenetre_supprimer");

	gtk_widget_destroy(fenetre_supprimer);
	fenetre_afficher=create_fenetre_afficher();
	gtk_widget_show(fenetre_afficher);

	treeview1=lookup_widget(fenetre_afficher,"treeview1");
	
	aff_capt(treeview1);


}




void
on_rechercher_capt_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{

	GtkWidget *fenetre_rechercher,*fenetre_afficher,*fenetre_alert_rech,*treeview1,*input;
	input=lookup_widget(objet,"id_rech");
	char id[10];
	int val;

	strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));

	fenetre_afficher=lookup_widget(objet,"fenetre_afficher");


	treeview1=lookup_widget(fenetre_afficher,"treeview1");
	rech_capt(id,treeview1,&val);
	
	if(val==0){
		fenetre_alert_rech=lookup_widget(objet,"fenetre_alert_rech");
		fenetre_alert_rech=create_fenetre_alert_rech();
		gtk_widget_show(fenetre_alert_rech);
	}
	


}


void
on_retourner5_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{

	GtkWidget *fenetre_rechercher,*fenetre_afficher,*treeview1;

	fenetre_rechercher=lookup_widget(objet,"fenetre_rechercher");

	gtk_widget_destroy(fenetre_rechercher);
	fenetre_afficher=create_fenetre_afficher();
	gtk_widget_show(fenetre_afficher);

	treeview1=lookup_widget(fenetre_afficher,"treeview1");
	
	aff_capt(treeview1);


}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		j=1;
	}


}


void
on_confirmer5_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{


	capteur capt;
	GtkWidget *fenetre_ajouter1;
	GtkWidget *fenetre_afficher,*fenetre_alert_id,*fenetre_alert_val,*fenetre_alert_idc;
	GtkWidget *treeview1;
	
	GtkWidget *input2,*input4;
	GtkWidget *jour,*mois,*annee;
	
	int trouve1=0,trouve2=0,trouve3=0;

	
	fenetre_ajouter1=lookup_widget(objet,"fenetre_ajouter1");
	
	
	input2=lookup_widget(objet,"id_ajt");
	input4=lookup_widget(objet,"v_ajt");

	jour=lookup_widget(objet,"jour");
	mois=lookup_widget(objet,"mois");
	annee=lookup_widget(objet,"annee");


	capt.date_capt.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
	capt.date_capt.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	capt.date_capt.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	

	if(j==1)
		strcpy(capt.marque,"A");
	else if(j==2)
		strcpy(capt.marque,"B");
	else if(j==3)
		strcpy(capt.marque,"C");

	strcpy(capt.id,gtk_entry_get_text(GTK_ENTRY(input2)));

	if(k==1)
		strcpy(capt.type,"Temp");
	else if(k==2)
		strcpy(capt.type,"Humd");
	else if(k==3)
		strcpy(capt.type,"Niv");

	strcpy(capt.valeur,gtk_entry_get_text(GTK_ENTRY(input4)));
	
	trouve3=test_val(capt.id);
	trouve1=test_id(capt);
	trouve2=test_val(capt.valeur);
	if(trouve1==1){
		fenetre_alert_idc=lookup_widget(objet,"fenetre_alert_idc");
		fenetre_alert_idc=create_fenetre_alert_idc();
		gtk_widget_show(fenetre_alert_idc);
	
	}
	else if(trouve2==1){
		fenetre_alert_val=lookup_widget(objet,"fenetre_alert_val");
		fenetre_alert_val=create_fenetre_alert_val();
		gtk_widget_show(fenetre_alert_val);
	}
	else if(trouve3==1){
		fenetre_alert_id=lookup_widget(objet,"fenetre_alert_id");
		fenetre_alert_id=create_fenetre_alert_id();
		gtk_widget_show(fenetre_alert_id);
	
	}
	else{
		ajt_capt(capt);

		gtk_widget_destroy(fenetre_ajouter1);
		fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
		fenetre_afficher=create_fenetre_afficher();
		
		gtk_widget_show(fenetre_afficher);
	
	
	
		treeview1=lookup_widget(fenetre_afficher,"treeview1");
	
		aff_capt(treeview1);			
		
	}
	

}


void
on_retourner6_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{

	GtkWidget *fenetre_ajouter1,*fenetre_afficher,*treeview1;

	fenetre_ajouter1=lookup_widget(objet,"fenetre_ajouter1");

	gtk_widget_destroy(fenetre_ajouter1);
	fenetre_afficher=create_fenetre_afficher();
	gtk_widget_show(fenetre_afficher);

	treeview1=lookup_widget(fenetre_afficher,"treeview1");
	
	aff_capt(treeview1);


}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		j=2;
	}


}


void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		j=3;
	}


}


void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		k=1;
	}


}


void
on_radiobutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		k=2;
	}

}


void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		k=3;
	}


}


void
on_radiobutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		l=1;
	}

}


void
on_radiobutton8_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		l=2;
	}

}


void
on_radiobutton9_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		l=3;
	}

}


void
on_radiobutton10_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		w=1;
	}

}


void
on_radiobutton11_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		w=2;
	}

}


void
on_radiobutton12_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		w=3;
	}

}


void
on_confirmer6_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{

	capteur capt;
	GtkWidget *fenetre_modifier;
	GtkWidget *fenetre_afficher,*fenetre_alert_id,*fenetre_alert_val,*fenetre_alert_idc;
	GtkWidget *treeview1;
	
	GtkWidget *input2,*input4;
	GtkWidget *jour,*mois,*annee;

	int trouve1=0,trouve2=0,trouve3=0;
	
	fenetre_modifier=lookup_widget(objet,"fenetre_modifier");
	

	
	input2=lookup_widget(objet,"id_modf1");
	input4=lookup_widget(objet,"v_modf1");

	jour=lookup_widget(objet,"spinbutton1");
	mois=lookup_widget(objet,"spinbutton2");
	annee=lookup_widget(objet,"spinbutton3");

	capt.date_capt.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
	capt.date_capt.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	capt.date_capt.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

	
	strcpy(capt.id,gtk_entry_get_text(GTK_ENTRY(input2)));

	if(l==1)
		strcpy(capt.marque,"A");
	else if(l==2)
		strcpy(capt.marque,"B");
	else if(l==3)
		strcpy(capt.marque,"C");

	

	if(w==1)
		strcpy(capt.type,"Temp");
	else if(w==2)
		strcpy(capt.type,"Humd");
	else if(w==3)
		strcpy(capt.type,"Niv");

	strcpy(capt.valeur,gtk_entry_get_text(GTK_ENTRY(input4)));

	trouve3=test_val(capt.id);
	trouve1=test_id(capt);
	trouve2=test_val(capt.valeur);
	/*if(trouve1==1){
		fenetre_alert_idc=lookup_widget(objet,"fenetre_alert_idc");
		fenetre_alert_idc=create_fenetre_alert_idc();
		gtk_widget_show(fenetre_alert_idc);
	
	}*/
	if(trouve2==1){
		fenetre_alert_val=lookup_widget(objet,"fenetre_alert_val");
		fenetre_alert_val=create_fenetre_alert_val();
		gtk_widget_show(fenetre_alert_val);
	}
	else if(trouve3==1){
		fenetre_alert_id=lookup_widget(objet,"fenetre_alert_id");
		fenetre_alert_id=create_fenetre_alert_id();
		gtk_widget_show(fenetre_alert_id);
	
	}
	else{

		modf_capt(capt);

		gtk_widget_destroy(fenetre_modifier);
		fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
		fenetre_afficher=create_fenetre_afficher();
		
		gtk_widget_show(fenetre_afficher);
	
	
	
		treeview1=lookup_widget(fenetre_afficher,"treeview1");
	
		aff_capt(treeview1);	


	}
}


void
on_retourner7_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data)
{

	GtkWidget *fenetre_modifier,*fenetre_afficher,*treeview1;

	fenetre_modifier=lookup_widget(objet,"fenetre_modifier");

	gtk_widget_destroy(fenetre_modifier);
	fenetre_afficher=create_fenetre_afficher();
	gtk_widget_show(fenetre_afficher);

	treeview1=lookup_widget(fenetre_afficher,"treeview1");
	
	aff_capt(treeview1);


}


void
on_retourner8_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	
	GtkWidget *fenetre_afficher,*treeview1;
	
	fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
	gtk_widget_destroy(fenetre_afficher);
	fenetre_afficher=create_fenetre_afficher();
	gtk_widget_show(fenetre_afficher);

	treeview1=lookup_widget(fenetre_afficher,"treeview1");

	
	
	aff_capt(treeview1);


}


void
on_refrecher_capt_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
	capteur capt;
	GtkWidget *output1,*output2,*output3,*output4;
	int kr,a,b,c;
	char text1[50];
	char text2[50];
	char text3[50];
	char text4[50];

	
	output1 = lookup_widget(objet,"label_1");
	output2 = lookup_widget(objet,"label_2");
	output3 = lookup_widget(objet,"label_3");
	output4 = lookup_widget(objet,"label_4");

	kr=num_capt_alarm(capt);
	marq_capt_defect(capt,&a,&b,&c);
	
	sprintf(text1,"%d\n",kr);
	sprintf(text2,"%d\n",a);
	sprintf(text3,"%d\n",b);
	sprintf(text4,"%d\n",c);
	
	GdkColor color1;
	gdk_color_parse("red",&color1);
	gtk_widget_modify_fg(output1,GTK_STATE_NORMAL,&color1);
	gtk_label_set_text(GTK_LABEL(output1),text1);

	GdkColor color2;
	gdk_color_parse("red",&color2);
	gtk_widget_modify_fg(output2,GTK_STATE_NORMAL,&color2);
	gtk_label_set_text(GTK_LABEL(output2),text2);
			
	GdkColor color3;
	gdk_color_parse("red",&color3);
	gtk_widget_modify_fg(output3,GTK_STATE_NORMAL,&color3);
	gtk_label_set_text(GTK_LABEL(output3),text3);

	GdkColor color4;
	gdk_color_parse("red",&color4);
	gtk_widget_modify_fg(output4,GTK_STATE_NORMAL,&color4);
	gtk_label_set_text(GTK_LABEL(output4),text4);

}








