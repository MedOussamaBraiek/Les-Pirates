#ifdef HAVE_CONFIG_H
#  include<config.h>
#endif

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"capteur.h"
#include<gtk/gtk.h>

enum{
	MARQUE,
	ID,
	TYPE,
	VALEUR,
	COLUMNS,
};



//------Ajouter Capteur------//

void ajt_capt(capteur capt){

	FILE *f;
	FILE *k;
	FILE *h;
	FILE *n;

	f = fopen("capt.txt","a+");
	k = fopen("temperature.txt","a+");
	h = fopen("humidite.txt","a+");
	n = fopen("niveau.txt","a+");

	if(f!=NULL){
		fprintf(f,"%s %s %s %s \n",capt.marque,capt.id, capt.type,capt.valeur);
		if(k!=NULL){
		if(strcmp(capt.type,"Temp")==0)
		fprintf(k,"%s %d %d %d %s \n",capt.id,capt.date_capt.jour, capt.date_capt.mois,capt.date_capt.annee,capt.valeur);
		fclose(k);}
		if(h!=NULL){
		if(strcmp(capt.type,"Humd")==0)
		fprintf(h,"%s %d %d %d %s \n",capt.id,capt.date_capt.jour, capt.date_capt.mois,capt.date_capt.annee,capt.valeur);
		fclose(h);}
		if(n!=NULL){
		if(strcmp(capt.type,"Niv")==0)
		fprintf(n,"%s %d %d %d %s \n",capt.id,capt.date_capt.jour, capt.date_capt.mois,capt.date_capt.annee,capt.valeur);
		fclose(n);}		
		
		fclose(f);
	}
	
}

//------Afficher Capteur------//

void aff_capt(GtkWidget *liste){

	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column; 
	GtkTreeIter iter;
	GtkListStore *store;

	char marque[10];
	char type[10];
	char valeur[10];
	char id[10];

	store=NULL;

	FILE *f;
	store=gtk_tree_view_get_model(liste);
	if(store==NULL){

		renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Marque",renderer,"text",MARQUE,NULL);				
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Identifiant",renderer,"text",ID,NULL);				
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Type",renderer,"text",TYPE,NULL);				
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Valeur",renderer,"text",VALEUR,NULL);				
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f = fopen("capt.txt","r");
	if(f==NULL){
		return;
	}
	else{
		f = fopen("capt.txt","a+");
		while(fscanf(f,"%s %s %s %s\n",marque,id,type,valeur)!=EOF){
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,MARQUE,marque,ID,id,TYPE,type,VALEUR,valeur,-1);

		}
		fclose(f);
		gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
	}	
	}
}


//------Supprimer Capteur------//

void supp_capt(capteur capt){

	char marque[10];
	char type[10];
	char valeur[10];
	char id[10];
	char jour[10];
	char mois[10];
	char annee[10];

	FILE *f,*k,*h,*n,*t1,*t2,*t3,*t4;
	f = fopen("capt.txt","r");
	k = fopen("temperature.txt","r");
	h = fopen("humidite.txt","r");
	n = fopen("niveau.txt","r");
	t1 = fopen("temp1.txt","w");
	t2 = fopen("temp2.txt","w");
	t3 = fopen("temp3.txt","w");
	t4 = fopen("temp4.txt","w");


	if(f==NULL || t1==NULL){
		return;
	}
	else{
		while(fscanf(f,"%s %s %s %s\n",marque,id,type,valeur)!=EOF){
		
			if(strcmp(capt.id,id)!=0){
				fprintf(t1,"%s %s %s %s\n",marque,id,type,valeur);
				
					if(strcmp(type,"Temp")==0){
						while(fscanf(k,"%s %s %s %s %s \n",id,jour,mois,annee,valeur)!=EOF){
							if(strcmp(capt.id,id)!=0)
								fprintf(t2,"%s %s %s %s %s \n",id,jour,mois,annee,valeur);
						}
					}
					else if(strcmp(type,"Humd")==0){
						while(fscanf(h,"%s %s %s %s %s \n",id,jour,mois,annee,valeur)!=EOF){
							if(strcmp(capt.id,id)!=0)
								fprintf(t3,"%s %s %s %s %s \n",id,jour,mois,annee,valeur);
						}
					}					
					else if(strcmp(type,"Niv")==0){
						while(fscanf(n,"%s %s %s %s %s \n",id,jour,mois,annee,valeur)!=EOF){
							if(strcmp(capt.id,id)!=0)
								fprintf(t4,"%s %s %s %s %s \n",id,jour,mois,annee,valeur);


						}
					}
				}

	
		     	}
		}

		fclose(k);
		fclose(h);
		fclose(n);
		fclose(f);
		fclose(t1);
		fclose(t2);
		fclose(t3);
		fclose(t4);
		remove("capt.txt");
		rename("temp1.txt","fichier.txt");
		remove("temperature.txt");
		rename("temp2.txt","temperature.txt");
		remove("humidite.txt");
		rename("temp3.txt","humidite.txt");
		remove("niveau.txt");
		rename("temp4.txt","niveau.txt");
		
	

}


//------Modifier Capteur------//

void modf_capt(capteur capt){

	char marque[10];
	char type[10];
	char valeur[10];
	char id[10];


	char jour[10];
	char mois[10];
	char annee[10];
	
	
	FILE *f,*t1,*k,*h,*n,*t2,*t3,*t4;
	
	f = fopen("capt.txt","r");
	k = fopen("temperature.txt","r");
	h = fopen("humidite.txt","r");
	n = fopen("niveau.txt","r");

	t1 = fopen("temp1.txt","w");
	t2 = fopen("temp2.txt","w");
	t3 = fopen("temp3.txt","w");
	t4 = fopen("temp4.txt","w");



	if(f==NULL || t1==NULL){
		return;
	}

	else{
		while(fscanf(f,"%s %s %s %s\n",marque,id,type,valeur)!=EOF){
		
		if(strcmp(capt.id,id)==0){
			fprintf(t1,"%s %s %s %s\n",capt.marque,capt.id,capt.type,capt.valeur);	
			if(strcmp(capt.type,"Temp")==0){
				fprintf(t2,"%s %d %d %d %s \n",capt.id,capt.date_capt.jour,capt.date_capt.mois,capt.date_capt.annee,capt.valeur);

				
			}



			else if(strcmp(capt.type,"Humd")==0){
				fprintf(t3,"%s %d %d %d %s \n",capt.id,capt.date_capt.jour,capt.date_capt.mois,capt.date_capt.annee,capt.valeur);

				
			}

			else if(strcmp(capt.type,"Niv")==0){
				fprintf(t4,"%s %d %d %d %s \n",capt.id,capt.date_capt.jour,capt.date_capt.mois,capt.date_capt.annee,capt.valeur);
					
	
				
			}
		}
		
		else{
			fprintf(t1,"%s %s %s %s\n",marque,id,type,valeur);
			if(strcmp(type,"Temp")==0){
				while(fscanf(k,"%s %s %s %s %s \n",id,jour,mois,annee,valeur)!=EOF){
					if(strcmp(capt.id,id)!=0)
						fprintf(t2,"%s %s %s %s %s \n",id,jour,mois,annee,valeur);
				}
			}	

			else if(strcmp(type,"Humd")==0){
				while(fscanf(h,"%s %s %s %s %s \n",id,jour,mois,annee,valeur)!=EOF){
					if(strcmp(capt.id,id)!=0)
						fprintf(t3,"%s %s %s %s %s \n",id,jour,mois,annee,valeur);
					
				}
			}
			else if(strcmp(type,"Niv")==0){
				while(fscanf(n,"%s %s %s %s %s \n",id,jour,mois,annee,valeur)!=EOF){
					if(strcmp(capt.id,id)!=0)
						fprintf(t4,"%s %s %s %s %s \n",id,jour,mois,annee,valeur);	
			
				}
			}
		}
		}
		fclose(k);
		fclose(h);
		fclose(n);
		fclose(f);
		fclose(t1);
		fclose(t2);
		fclose(t3);
		fclose(t4);
		remove("temperature.txt");
		rename("temp2.txt","temperature.txt");
		remove("humidite.txt");
		rename("temp3.txt","humidite.txt");
		remove("niveau.txt");
		rename("temp4.txt","niveau.txt");
		remove("capt.txt");
		rename("temp1.txt","capt.txt");
	}	
}


//------Les nombres des Capteurs defectueux------//


int num_capt_alarm(capteur capt){


	char marque[10];
	char type[10];
	char valeur[10];
	char id[10];
	float valf;
	int vali;
	int k=0;
	FILE *f;	
	f = fopen("capt.txt","r");
	if(f==NULL){
		return;
	}
	else{

		while(fscanf(f,"%s %s %s %s\n",marque,id,type,valeur)!=EOF){
			if(strcmp(type,"Temp")==0){
					valf=atof(valeur);
					if(valf>100 || valf<-40)
						k++;
				}
			else if(strcmp(type,"Humd")==0){
					vali=atoi(valeur);
					if(vali>99 || vali<1)
						k++;
				}
			else if(strcmp(type,"Niv")==0){
					vali=atoi(valeur);
					if(vali>3 || vali<0)
						k++;
				}
		}
		fclose(f);	
	}

	return(k);
		
}


//------Les marques des Capteurs ayant des valeurs alarmentes------//


void marq_capt_defect(capteur capt,int *t,int *h,int *e){

	char marque[10];
	char type[10];
	char valeur[10];
	char id[10];

	*t=0,*h=0,*e=0;
	float valf;
	int vali;
	
	FILE *f;	
	f = fopen("capt.txt","r");
	if(f==NULL){
		return;
	}
	
	else{
		
		while(fscanf(f,"%s %s %s %s\n",marque,id,type,valeur)!=EOF){
				
			  
			
			
			if(strcmp(marque,"A")==0){
				if(strcmp(type,"Temp")==0){
					valf=atof(valeur);
					if(valf>100 || valf<-40)
						*t=*t+1;
				}
				else if(strcmp(type,"Humd")==0){
					vali=atoi(valeur);
					if(vali>99 || vali<1)
						*t=*t+1;
				}
				else if(strcmp(type,"Niv")==0){
					vali=atoi(valeur);
					if(vali>3 || vali<0)
						*t=*t+1;
				}
			}
			if(strcmp(marque,"B")==0){
				if(strcmp(type,"Temp")==0){
					valf=atof(valeur);
					if(valf>100 || valf<-40)
						*h=*h+1;
				}
				else if(strcmp(type,"Humd")==0){
					vali=atoi(valeur);
					if(vali>99 || vali<1)
						*h=*h+1;
				}
				else if(strcmp(type,"Niv")==0){
					vali=atoi(valeur);
					if(vali>3 || vali<0)
						*h=*h+1;
				}
			}
			if(strcmp(marque,"C")==0){
				if(strcmp(type,"Temp")==0){
					valf=atof(valeur);
					if(valf>100 || valf<-40)
						*e=*e+1;
				}
				else if(strcmp(type,"Humd")==0){
					vali=atoi(valeur);
					if(vali>99 || vali<1)
						*e=*e+1;
				}
				else if(strcmp(type,"Niv")==0){
					vali=atoi(valeur);
					if(vali>3 || vali<0)
						*e=*e+1;
				}
			}

			
		}		
		
		fclose(f);
	}

}


//------Rechercher Capteur------//

void rech_capt(char id1[10],GtkWidget *liste,int *trouve){
	
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column; 
	GtkTreeIter iter;
	GtkListStore *store;

	capteur capt;
	char marque[10];
	char type[10];
	char valeur[10];
	char id[10];
	*trouve=0;

	store=NULL;

	FILE *f;
	store=gtk_tree_view_get_model(liste);
	if(store==NULL){

		renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Marque",renderer,"text",MARQUE,NULL);				
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Identifiant",renderer,"text",ID,NULL);				
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Type",renderer,"text",TYPE,NULL);				
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Valeur",renderer,"text",VALEUR,NULL);				
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


	}
	store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f = fopen("capt.txt","r");
	if(f==NULL){
		return;
	}
	else{
		f = fopen("capt.txt","r");
		while(fscanf(f,"%s %s %s %s\n",capt.marque,capt.id,capt.type,capt.valeur)!=EOF){
			if((strcmp(capt.id,id1)==0)){
				gtk_list_store_append(store,&iter);
							  gtk_list_store_set(store,&iter,MARQUE,capt.marque,ID,capt.id,TYPE,capt.type,VALEUR,capt.valeur,-1);
				*trouve=1;
			
			}
		}
		fclose(f);
		gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
	}	
	}
	


//------Fonction permet de tester la continue de chaine------//


int test_val(char *chaine){

	int trouve=0;
	while((*chaine>='0' && *chaine<='9')||(*chaine=='-')||(*chaine=='.'))
		*chaine++;
	if(*chaine)
		trouve=1;
	return(trouve);

}


//------Fonction permet de tester si L'ID est exister ou non------//

int test_id(capteur capt){
	
	char marque[10];
	char type[10];
	char valeur[10];
	char id[10];
	int trouve=0;

	FILE *f;
	
	f = fopen("capt.txt","r");
	if(f==NULL){
		return;	
	}	
	
	else{
		while(fscanf(f,"%s %s %s %s\n",marque,id,type,valeur)!=EOF){
			if(strcmp(capt.id,id)==0){
				trouve=1;
			}

		}
	fclose(f);	
	}

	return(trouve);
}



void spin_button_get_val(capteur capt,int *jourint,int *moisint,int *anneeint){

	char marque[10];
	char type[10];
	char valeur[10];
	char id[10];
	char jour[10];
	char mois[10];
	char annee[10];


	FILE *k,*h,*n;
	k = fopen("temperature.txt","r");
	h = fopen("humidite.txt","r");
	n = fopen("niveau.txt","r");

	if(k==NULL || h==NULL || n==NULL){
		return;
	}
	else{
		if(strcmp(capt.type,"Temp")==0){
			while(fscanf(k,"%s %s %s %s %s \n",id,jour,mois,annee,valeur)!=EOF){
				if(strcmp(capt.id,id)==0){
					*jourint=atoi(jour);
					*moisint=atoi(mois);
					*anneeint=atoi(annee);
				}	
			}
		}
		else if(strcmp(capt.type,"Humd")==0){
			while(fscanf(h,"%s %s %s %s %s \n",id,jour,mois,annee,valeur)!=EOF){
				if(strcmp(capt.id,id)==0){
					*jourint=atoi(jour);
					*moisint=atoi(mois);
					*anneeint=atoi(annee);
				}
			}
		}					
		else if(strcmp(capt.type,"Niv")==0){
			while(fscanf(n,"%s %s %s %s %s \n",id,jour,mois,annee,valeur)!=EOF){
				if(strcmp(capt.id,id)==0){
					*jourint=atoi(jour);
					*moisint=atoi(mois);
					*anneeint=atoi(annee);

				}
			}
		}
	}

		fclose(k);
		fclose(h);
		fclose(n);

}
