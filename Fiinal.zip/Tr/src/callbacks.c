#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
#include "equip.h"
#include "capteur.h"
#include "client.h"
#include "fonc.h"

troupeaux selected_tr;

int x, y, z;
int a, b, c;
int j,k,l,w;

char y1[30];
char z1[30];

//-----------Button Ajouter------------//

void
on_aj_tr_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *troupeauxx;
	GtkWidget *gestion_tr;

	troupeauxx=lookup_widget(objet, "troupeauxx");
	gtk_widget_destroy(troupeauxx);

	//inscrit_emp=lookup_widget(objet, "inscrit_emp");
	//troupeauxx=create_troupeauxx();
	gestion_tr=create_gestion_tr();
	gtk_widget_show(gestion_tr);
}


//-----------Button Modifier------------//

void
on_md_tr_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *troupeauxx;
GtkWidget *modifier_troupeaux;

GtkWidget *treeview1;
GtkTreeSelection *selection ;
GtkTreeModel *model;
GtkTreeIter iter;
GtkToggleButton *brebi1, *veau1;
GtkWidget *button;
GSList *group;

	gchar* id;
	gchar* type;
	gchar* genre;
	gchar* jour;
	gchar* mois;
	gchar* annee;
	gchar* etat;

troupeaux tr_modif;



GtkWidget *input1,*combobox1,*combobox2,*input4,*input5,*input6,*JOUR,*MOIS,*ANNEE;


	troupeauxx=lookup_widget(objet,"troupeauxx");

    treeview1=lookup_widget(troupeauxx,"treeview1");
    selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview1));

    if(gtk_tree_selection_get_selected(selection,&model,&iter)) {
        // Obtention des varietes de la ligne selectionnée
        gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&id ,1,&type, 2,&genre, 3,&jour, 4,&mois, 5,&annee, 6,&etat,-1);

	int jour_i,mois_i,annee_i;
	jour_i=atoi(jour);
	mois_i=atoi(mois);
	annee_i=atoi(annee);
        //p_modif.id=id;
        strcpy(tr_modif.id,id);
        strcpy(tr_modif.type,type);
        strcpy(tr_modif.genre,genre);
        
	tr_modif.d.jour=jour_i;
	tr_modif.d.mois=mois_i;
	tr_modif.d.annee=annee_i;
 	strcpy(tr_modif.etat,etat);
    }

    gtk_widget_destroy(troupeauxx);

    modifier_troupeaux=create_modifier_troupeaux();
    gtk_widget_show(modifier_troupeaux);

    input1=lookup_widget(modifier_troupeaux,"id_tr1");
    
    JOUR=lookup_widget(modifier_troupeaux,"jour1");
    MOIS=lookup_widget(modifier_troupeaux,"mois1");
    ANNEE=lookup_widget(modifier_troupeaux,"annee1");

	
    gtk_entry_set_text(GTK_ENTRY(input1),tr_modif.id);
    
   gtk_spin_button_set_value(JOUR,tr_modif.d.jour);
   gtk_spin_button_set_value(MOIS,tr_modif.d.mois);
   gtk_spin_button_set_value(ANNEE,tr_modif.d.annee);

	GtkWidget *type1,*genre1,*etat1;
	type1=lookup_widget(modifier_troupeaux,"type11");
	genre1=lookup_widget(modifier_troupeaux,"genre11");
	etat1=lookup_widget(modifier_troupeaux,"etat11");
	char veau[10] = "Veau";
	char brebi[10] = "Brebi";
	char male[10] = "Male";
	char female[10] = "Female";
	char vivant[10] = "Vivant";
	char mort[10] = "Mort";
	if((strcmp(type, veau))==0)
	{
	GdkColor color;
	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(type1,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(type1),"Veau");
	
	}
	if((strcmp(type, brebi))==0)
	{
	GdkColor color;
	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(type1,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(type1),"Brebi");
	
	}

	if((strcmp(genre, male))==0)
	{
	GdkColor color;
	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(genre1,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(genre1),"Male");
	
	}
	if((strcmp(genre, female))==0)
	{
	GdkColor color;
	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(genre1,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(genre1),"Female");
	
	}
	if((strcmp(etat, vivant))==0)
	{
	GdkColor color;
	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(etat1,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(etat1),"Vivant");
	
	}
	if((strcmp(etat, mort))==0)
	{
	GdkColor color;
	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(etat1,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(etat1),"Mort");
	
	}
	

}


//-----------Button Supprimer------------//

void
on_supp_tr_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	

	GtkWidget *troupeauxx, *treeview1;
	GtkTreeModel *model;
	GtkTreeIter iter;
	GtkTreeSelection *selection;

	gchar* id;
	gchar* type;
	gchar* genre;
	gchar* jour;
	gchar* mois;
	gchar* annee;
	gchar* etat;

	troupeaux tr;

	troupeauxx= lookup_widget(objet,"troupeauxx");
	treeview1=lookup_widget(troupeauxx,"treeview1");
	selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview1));

	if(gtk_tree_selection_get_selected(selection,&model,&iter))
	{
	gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&id ,1,&type, 2,&genre, 3,&jour, 4,&mois, 5,&annee, 6,&etat,-1);
		
				
		strcpy(tr.id,id);
		strcpy(tr.type,type);
		strcpy(tr.genre,genre);
		strcpy(tr.jour,jour);
		strcpy(tr.mois,mois);		
		strcpy(tr.annee,annee);
		strcpy(tr.etat,etat);
		
		troupeauxx= lookup_widget(objet,"troupeauxx");
		gtk_widget_destroy(troupeauxx);
		troupeauxx= create_troupeauxx();
		gtk_widget_show(troupeauxx);
		treeview1=lookup_widget(troupeauxx,"treeview1");
		sup_tr(tr);

		aff_tr(treeview1);

	}

}

//-----------Button Confirmer------------//


void
on_conf_tr_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *gestion_tr;
	GtkWidget *troupeauxx;
	GtkWidget *treeview1;
	troupeaux tr;

	GtkWidget *jour;
	GtkWidget *mois;
	GtkWidget *annee;	

	GtkWidget *input1, *input2, *input3, *input4, *sortie; 

	input1=lookup_widget(objet,"id_tr");
	sortie=lookup_widget(objet,"label42");
	

	strcpy(tr.id,gtk_entry_get_text(GTK_ENTRY(input1)));
	

	
	if(x==1)
		strcpy(tr.type,"Brebi");
	else if(x==2)
		strcpy(tr.type,"Veau");
	

	if(y==1)
		strcpy(tr.genre,"Male");
	else if(y==2)
		strcpy(tr.genre,"Female");

	jour = lookup_widget(objet, "jour");
	mois = lookup_widget(objet, "mois");
	annee = lookup_widget(objet, "annee");

	tr.d.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
	tr.d.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
	tr.d.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));


	if(z==1)
		strcpy(tr.etat,"Vivant");
	else if(z==2)
		strcpy(tr.etat,"Mort");
	
	char id[30];
  	char type[30];
 	char genre[30];
 	char jour1[30];
  	char mois1[30];
  	char annee1[30];
  	char etat[30];
	int trouve=0;
		
	FILE *f;
	f = fopen("fichier.txt","r");

	while(fscanf(f,"%s %s %s %s %s %s %s \n",id,type,genre,jour1,mois1,annee1,etat)!=EOF)
		{
			if((strcmp(id, tr.id))==0)
				trouve=1;
		}

	if(trouve!=1)
	{
	GdkColor color;
	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie),"Troupeaux ajoutée");
	

	ajt_tr(tr);
	
	aff_tr(treeview1);
	}
	else
	{
	GdkColor color;
	gdk_color_parse("red",&color);
	gtk_widget_modify_fg(sortie,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie),"Troupeaux deja existé");
	}
}


void
on_retour_tr_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *troupeauxx, *gestion_tr,*treeview1;

	gestion_tr = lookup_widget(objet,"gestion_tr");
	gtk_widget_destroy(gestion_tr);

	troupeauxx = create_troupeauxx();
	gtk_widget_show(troupeauxx);

	treeview1=lookup_widget(troupeauxx,"treeview1");
	
	aff_tr(treeview1);
}


void
on_retour1_tr_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *troupeauxx, *supp_tr,*treeview1;

	supp_tr = lookup_widget(objet,"supp_tr");
	gtk_widget_destroy(supp_tr);

	troupeauxx = create_troupeauxx();
	gtk_widget_show(troupeauxx);

	treeview1=lookup_widget(troupeauxx,"treeview1");
	
	aff_tr(treeview1);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* id;
	gchar* type;
	gchar* genre;
	gint* jour;
	gint* mois;
	gint* annee;
	gchar* etat;
	
	troupeaux tr;

	GtkTreeModel *model = gtk_tree_view_get_model(treeview);

	//GtkWidget *get_hscrollbar_new(GtkAdjustment *adjustment);

	if(gtk_tree_model_get_iter(model,&iter,path))
	{
		

	gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&id ,1,&type, 2,&genre, 3,&jour, 4,&mois, 5,&annee, 6,&etat,-1);
		
				
		strcpy(tr.id,id);
		strcpy(tr.type,type);
		strcpy(tr.genre,genre);
		tr.d.jour=*jour;
		tr.d.mois=*mois;
		tr.d.annee=*annee;
		strcpy(tr.etat,etat);
		
		sup_tr(tr);

		aff_tr(treeview);

	}

}
	


//---------Bouton1 Chercher troupeaux----------//

void
on_button_rechercher_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget  *troupeauxx,*f_chercher_tr;

troupeauxx=lookup_widget(objet,"troupeauxx");

gtk_widget_destroy(troupeauxx);

f_chercher_tr=lookup_widget(objet,"f_chercher_tr");
f_chercher_tr=create_f_chercher_tr();
gtk_widget_show(f_chercher_tr);

   
}


void
on_rt_md_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *troupeauxx, *modifier_troupeaux,*treeview1;

	modifier_troupeaux = lookup_widget(objet,"modifier_troupeaux");
	gtk_widget_destroy(modifier_troupeaux);

	troupeauxx = create_troupeauxx();
	gtk_widget_show(troupeauxx);

	treeview1=lookup_widget(troupeauxx,"treeview1");
	
	aff_tr(treeview1);
}


void
on_enregistre_tr_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *modifier_troupeaux;
	GtkWidget *troupeauxx;
	GtkWidget *treeview1;
	troupeaux tr;
	GtkWidget *input1, *input2, *input3, *input4, *input5, *input6, *input7,*sortie;
	//GtkWidget *liste_emp, *inscrit_emp;
	sortie=lookup_widget(objet,"label51");
	input1=lookup_widget(objet,"id_tr1");
	
	//input5=lookup_widget(objet,"entry_specialite1");
	

	strcpy(tr.id,gtk_entry_get_text(GTK_ENTRY(input1)));
	
	//strcpy(tr.etat,gtk_entry_get_text(GTK_ENTRY(input5)));

	if(a==1)
		strcpy(tr.type,"Brebi");
	else if(a==2)
		strcpy(tr.type,"Veau");
	

	if(b==1)
		strcpy(tr.genre,"Male");
	else if(b==2)
		strcpy(tr.genre,"Female");


	input2 = lookup_widget(objet, "jour1");
	input3 = lookup_widget(objet, "mois1");
	input4 = lookup_widget(objet, "annee1");

	tr.d.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input2));
	tr.d.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input3));
	tr.d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input4));


	if(c==1)
		strcpy(tr.etat,"Vivant");
	else if(c==2)
		strcpy(tr.etat,"Mort");
	
	
	
	modf_tr(tr);

	GdkColor color;
	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie),"Troupeaux modifier");


}





void
on_veau_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		x=2;
	}
}


void
on_male_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		y=1;
	}
}


void
on_female_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		y=2;
	}
}


void
on_vivant_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		z=1;
	}
}


void
on_mort_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		z=2;
	}
}


void
on_brebi_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		x=1;
	}
}


void
on_brebi1_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		a=1;
	}
}

void
on_veau1_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		a=2;
	}	
}

void
on_male1_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		b=1;
	}
}

void
on_female1_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		b=2;
	}

}
void
on_vivant1_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		c=1;
	}
}

void
on_mort1_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		c=2;
	}
}

void
on_refrech_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	troupeaux tr;

	GtkWidget *troupeauxx;
	GtkWidget *treeview1;
	GtkWidget *output;


	//gtk_widget_destroy(troupeauxx);
	troupeauxx=lookup_widget(objet,"troupeauxx");
	//troupeauxx = create_troupeauxx();
	//gtk_widget_show(troupeauxx);*/

	treeview1 = lookup_widget(troupeauxx, "treeview1");

	aff_tr(treeview1);

}

void
on_dispo_id_tr_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
    troupeaux tr;
    GtkWidget *id1;
    id1 = lookup_widget(objet, "combobox1");
    FILE *f;
    f = fopen("fichier.txt","r");
    if(f!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %s %s %s\n",tr.id,tr.type,tr.genre,tr.jour,tr.mois,tr.annee,tr.etat)!=EOF)
        {
            gtk_combo_box_append_text(GTK_COMBO_BOX(id1),_(tr.id));
        }
    }

}



void
on_affichage_tr_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *gestion_tr;	
	GtkWidget *troupeauxx;
	GtkWidget *treeview1;

	gestion_tr = lookup_widget(objet,"gestion_tr");
	gtk_widget_destroy(gestion_tr);

	
	troupeauxx = lookup_widget(objet,"troupeaux");
	troupeauxx = create_troupeauxx();
	gtk_widget_show(troupeauxx);

	treeview1=lookup_widget(troupeauxx,"treeview1");

	aff_tr(treeview1);

}

//-----------Button refrech ID-------------

void
on_refrech_rech_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
    troupeaux tr;
    GtkWidget *id1;
    GtkWidget *type1;
    GtkWidget *genre1;
    id1 = lookup_widget(objet, "combobox_id");
    FILE *f;
    f = fopen("fichier.txt","r");
    if(f!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %s %s %s\n",tr.id,tr.type,tr.genre,tr.jour,tr.mois,tr.annee,tr.etat)!=EOF)
        {
            gtk_combo_box_append_text(GTK_COMBO_BOX(id1),_(tr.id));
        }
    }

}

//----------Button2 Chercher troupeaux-------------//

void
on_rech_tr_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{

FILE *f;

f = fopen("tr1.txt","r");	

    /*char id1[30];
	char id2[30];
    char type1[30];
	char genre1[30];
	char vide[10]="";
    troupeaux tr;
    GtkWidget *input1,*input2,*input3,*sortie,*input5;
    /*GtkWidget *f_chercher_tr;
	GtkWidget *treeview2;
    treeview2 = lookup_widget(objet, "treeview2");
    sortie=lookup_widget(objet,"label45");
    f_chercher_tr = lookup_widget(objet,"f_chercher_tr");

    input1 = lookup_widget(objet,"combobox_id");
    input2 = lookup_widget(objet,"combobox_type");
    input3 = lookup_widget(objet,"combobox_genre");

    if(strcmp(vide,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)))!=0)
    strcpy(id1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));*/

 /*if(strcmp(vide,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input2)))!=0)
    strcpy(id1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input2)));

if(strcmp(vide,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input3)))!=0)
    strcpy(id1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input3)));*/
    

	
	/*input5=lookup_widget(objet, "entry_chercher");
  strcpy(id2,gtk_entry_get_text(GTK_ENTRY(input5)));


    rechercher_tr(tr,id1);
    gtk_entry_set_text(GTK_ENTRY(input1),"");
    

    affichage_rechercher(treeview2);*/


	char id1[20];
	int trouve=0;
troupeaux tr;
GtkWidget *input7,*sortie;
GtkWidget *f_chercher_tr;

sortie=lookup_widget(objet,"label45");

f_chercher_tr=lookup_widget(objet,"f_chercher_tr");

input7=lookup_widget(objet,"entry_chercher");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(input7)));
trouve=rechercher_tr(tr,id1);
gtk_entry_set_text(GTK_ENTRY(input7),"");

GtkWidget *treeview2;
treeview2=lookup_widget(objet,"treeview2");
affichage_rechercher(treeview2);	

	if(trouve==1){
	GdkColor color;
	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie),"Troupeaux trouvé");}
	else{
	GdkColor color;
	gdk_color_parse("red",&color);
	gtk_widget_modify_fg(sortie,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie),"N'existe pas");
	}

}


void
on_return_rech_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget  *f_chercher_tr,*troupeauxx, *treeview1;
	f_chercher_tr=lookup_widget(objet,"f_chercher_tr");

	gtk_widget_destroy(f_chercher_tr);
	troupeauxx=lookup_widget(objet,"troupeauxx");
	troupeauxx=create_troupeauxx();
	gtk_widget_show(troupeauxx);

	treeview1=lookup_widget(troupeauxx,"treeview1");
	
	aff_tr(treeview1);

}


void
on_aff_tr_md_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *modifier_troupeaux;	
	GtkWidget *troupeauxx;
	GtkWidget *treeview1;

	modifier_troupeaux = lookup_widget(objet,"modifier_troupeaux");
	gtk_widget_destroy(modifier_troupeaux);

	
	troupeauxx = lookup_widget(objet, "troupeauxx");
	troupeauxx = create_troupeauxx();
	gtk_widget_show(troupeauxx);

	treeview1=lookup_widget(troupeauxx,"treeview1");
	
	aff_tr(treeview1);

}


void
on_result_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *sortie, *veau, *brebi,*vivant;
	GtkWidget *troupeauxx;
	char nbr_s[10];
	char iv_s[10];
	char ib_s[10];
	char ivv_s[10];
	int nbr,iv,ib,ivv;
	sortie=lookup_widget(objet,"nbr_tr");
	veau=lookup_widget(objet,"nbr_veau");
	brebi=lookup_widget(objet,"nbr_brebi");
	vivant=lookup_widget(objet,"nbr_vivant");

	troupeaux tr;

	

	troupeauxx=lookup_widget(objet,"troupeauxx");
	

	nbr=nombre_troupeaux();
	sprintf(nbr_s,"%d", nbr);

	GdkColor color;
	gdk_color_parse("red",&color);
	gtk_widget_modify_fg(sortie,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie),nbr_s);

	iv=nombre_veau();
	sprintf(iv_s,"%d", iv);


	gdk_color_parse("red",&color);
	gtk_widget_modify_fg(veau,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(veau),iv_s);

	ib=nombre_brebi();
	sprintf(ib_s,"%d", ib);


	gdk_color_parse("red",&color);
	gtk_widget_modify_fg(brebi,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(brebi),ib_s);

	ivv=troupeaux_vivant();
	sprintf(ivv_s,"%d", ivv);


	gdk_color_parse("red",&color);
	gtk_widget_modify_fg(vivant,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(vivant),ivv_s);

}


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

	
	GtkTreeIter iter;
	gchar* id;
	gchar* type;
	gchar* genre;
	gint* jour;
	gint* mois;
	gint* annee;
	gchar* etat;
	
	troupeaux tr;

	GtkTreeModel *model = gtk_tree_view_get_model(treeview);

	if(gtk_tree_model_get_iter(model,&iter,path))
	{
		

	gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&id ,1,&type, 2,&genre, 3,&jour, 4,&mois, 5,&annee, 6,&etat,-1);
		
				
		strcpy(tr.id,id);
		strcpy(tr.type,type);
		strcpy(tr.genre,genre);
		tr.d.jour=*jour;
		tr.d.mois=*mois;
		tr.d.annee=*annee;
		strcpy(tr.etat,etat);
		
		//sup_tr(tr);

		aff_tr(treeview);

	}

}




void
on_employe_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{

	GtkWidget *users;	
	GtkWidget *auth_emp;

	users = lookup_widget(objet,"users");
	gtk_widget_destroy(users);

	
	auth_emp = lookup_widget(objet, "auth_emp");
	auth_emp = create_auth_emp();
	gtk_widget_show(auth_emp);

}


void
on_administrateur_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *users;	
	GtkWidget *auth_ad;

	users = lookup_widget(objet,"users");
	gtk_widget_destroy(users);

	
	auth_ad = lookup_widget(objet, "auth_ad");
	auth_ad = create_auth_ad();
	gtk_widget_show(auth_ad);
}


void
on_proprietaire_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *users;	
	GtkWidget *auth_pr;

	users = lookup_widget(objet,"users");
	gtk_widget_destroy(users);

	
	auth_pr = lookup_widget(objet, "auth_pr");
	auth_pr = create_auth_pr();
	gtk_widget_show(auth_pr);
}


void
on_entrer_emp_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *input1, *input2,*work,*auth_emp,*sortie;
	int trouve;
	char log[20];
	char pw[20];
	input1=lookup_widget(objet,"entry_login_emp");
	input2=lookup_widget(objet,"entry_pw_emp");
	sortie=lookup_widget(objet,"label71");
	strcpy(log,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(pw,gtk_entry_get_text(GTK_ENTRY(input2)));
	trouve=verif_emp(log,pw);

	if(trouve==1)
	{
	auth_emp = lookup_widget(objet,"auth_emp");
	gtk_widget_destroy(auth_emp);

	
	work = lookup_widget(objet, "work");
	work = create_work();
	gtk_widget_show(work);

	}
	else
	{
	GdkColor color;
	gdk_color_parse("red",&color);
	gtk_widget_modify_fg(sortie,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie),"Identifiant ou Mot de passe incorrect");
	}
	
}


void
on_inscription_emp_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *auth_emp;	
	GtkWidget *inscription_emp;

	auth_emp = lookup_widget(objet,"auth_emp");
	gtk_widget_destroy(auth_emp);

	
	inscription_emp = lookup_widget(objet, "inscription_emp");
	inscription_emp = create_inscription_emp();
	gtk_widget_show(inscription_emp);
}


void
on_insc_aj_emp_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	
FILE *f=NULL;
GtkWidget *nom, *prenom, *username, *pw, *auth_emp, *inscription_emp;
char nom1[20];
char prenom1[20];
char username1[20];
char password1[20];

nom = lookup_widget (objet, "entry_nom_emp");
prenom = lookup_widget (objet, "entry_prenom_emp");
username = lookup_widget (objet, "entry_identifiant_emp");
pw = lookup_widget (objet, "entry_pw_emp");

strcpy(nom1, gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(prenom1, gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(username1, gtk_entry_get_text(GTK_ENTRY(username)));
strcpy(password1, gtk_entry_get_text(GTK_ENTRY(pw)));


//ouvrir le fichier
f=fopen("employe.txt", "a+");
if(f!=NULL)
{
//ecrire dans le fichier
fprintf(f, "%s  %s  %s  %s \n",nom1, prenom1, username1, password1); 
fclose(f);

}
inscription_emp = lookup_widget(objet,"inscription_emp");
	gtk_widget_destroy(inscription_emp);
auth_emp=create_auth_emp();
gtk_widget_show(auth_emp);	
}


void
on_retour_auth_emp_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *auth_emp;	
	GtkWidget *inscription_emp;

	inscription_emp = lookup_widget(objet,"inscription_emp");
	gtk_widget_destroy(inscription_emp);

	
	auth_emp = lookup_widget(objet, "auth_emp");
	auth_emp = create_auth_emp();
	gtk_widget_show(auth_emp);
}


void
on_rt_emp_users_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *auth_emp;	
	GtkWidget *users;

	auth_emp = lookup_widget(objet,"auth_emp");
	gtk_widget_destroy(auth_emp);

	
	users = lookup_widget(objet, "users");
	users = create_users();
	gtk_widget_show(users);
}


void
on_fermer_tr_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *troupeauxx;	
	GtkWidget *users;

	troupeauxx = lookup_widget(objet,"troupeauxx");
	gtk_widget_destroy(troupeauxx);

	
	users = lookup_widget(objet, "users");
	users = create_users();
	gtk_widget_show(users);
}


void
on_button_troupeaux_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *troupeauxx;	
	GtkWidget *work;

	work = lookup_widget(objet,"work");
	gtk_widget_destroy(work);

	
	troupeauxx = lookup_widget(objet, "troupeauxx");
	troupeauxx = create_troupeauxx();
	gtk_widget_show(troupeauxx);
}


void
on_button_equipment_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *equipement;	
	GtkWidget *work;

	work = lookup_widget(objet,"work");
	gtk_widget_destroy(work);

	
	equipement = lookup_widget(objet, "equipement");
	equipement = create_equipement();
	gtk_widget_show(equipement);
}


void
on_button_capteurs_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_afficher,*treeview3;	
	GtkWidget *work;

	work = lookup_widget(objet,"work");
	gtk_widget_destroy(work);

	
	fenetre_afficher = lookup_widget(objet, "fenetre_afficher");
	fenetre_afficher = create_fenetre_afficher();
	gtk_widget_show(fenetre_afficher);
	treeview3=lookup_widget(fenetre_afficher,"treeview3");
	aff_capt(treeview3);
}


void
on_rt_ad_users_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *auth_ad;	
	GtkWidget *users;

	auth_ad = lookup_widget(objet,"auth_ad");
	gtk_widget_destroy(auth_ad);

	
	users = lookup_widget(objet, "users");
	users = create_users();
	gtk_widget_show(users);
}


void
on_inscription_ad_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *auth_ad;	
	GtkWidget *inscription_ad;

	auth_ad = lookup_widget(objet,"auth_ad");
	gtk_widget_destroy(auth_ad);

	
	inscription_ad = lookup_widget(objet, "inscription_ad");
	inscription_ad = create_inscription_ad();
	gtk_widget_show(inscription_ad);
}


void
on_entrer_ad_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *input1, *input2,*work,*auth_ad,*sortie;
	int trouve;
	char log[20];
	char pw[20];
	input1=lookup_widget(objet,"entry_login_ad");
	input2=lookup_widget(objet,"entry_pw_ad");
	sortie=lookup_widget(objet,"label70");
	strcpy(log,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(pw,gtk_entry_get_text(GTK_ENTRY(input2)));
	trouve=verif_ad(log,pw);

	if(trouve==1)
	{
	auth_ad = lookup_widget(objet,"auth_ad");
	gtk_widget_destroy(auth_ad);

	
	work = lookup_widget(objet, "work");
	work = create_work();
	gtk_widget_show(work);

	}
	else
	{
	GdkColor color;
	gdk_color_parse("red",&color);
	gtk_widget_modify_fg(sortie,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie),"Identifiant ou Mot de passe incorrect");
	}
}


void
on_rt_auth_ad_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *auth_ad;	
	GtkWidget *inscription_ad;

	inscription_ad = lookup_widget(objet,"inscription_ad");
	gtk_widget_destroy(inscription_ad);

	
	auth_ad = lookup_widget(objet, "auth_ad");
	auth_ad = create_auth_ad();
	gtk_widget_show(auth_ad);
}


void
on_insc_aj_ad_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	FILE *f=NULL;
GtkWidget *nom, *prenom, *username, *pw, *auth_ad, *inscription_ad;
char nom1[20];
char prenom1[20];
char username1[20];
char password1[20];

nom = lookup_widget (objet, "entry_nom_ad");
prenom = lookup_widget (objet, "entry_prenom_ad");
username = lookup_widget (objet, "entry_identifiant_ad");
pw = lookup_widget (objet, "entry_pw_ad");

strcpy(nom1, gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(prenom1, gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(username1, gtk_entry_get_text(GTK_ENTRY(username)));
strcpy(password1, gtk_entry_get_text(GTK_ENTRY(pw)));


//ouvrir le fichier
f=fopen("administrateur.txt", "a+");
if(f!=NULL)
{
//ecrire dans le fichier
fprintf(f, "%s  %s  %s  %s \n",nom1, prenom1, username1, password1); 
fclose(f);

}
inscription_ad = lookup_widget(objet,"inscription_ad");
	gtk_widget_destroy(inscription_ad);
auth_ad=create_auth_ad();
gtk_widget_show(auth_ad);
}



void
on_aff_vivant_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *troupeauxx, *treeview1;

troupeauxx=lookup_widget(objet, "troupeauxx");
gtk_widget_destroy(troupeauxx);
troupeauxx=create_troupeauxx();
gtk_widget_show(troupeauxx);

treeview1=lookup_widget(troupeauxx,"treeview1");
aff_vivant(treeview1);
}


void
on_aff_veau_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *troupeauxx, *treeview1;

troupeauxx=lookup_widget(objet, "troupeauxx");
gtk_widget_destroy(troupeauxx);
troupeauxx=create_troupeauxx();
gtk_widget_show(troupeauxx);

treeview1=lookup_widget(troupeauxx,"treeview1");
aff_veau(treeview1);
}


void
on_aff_brebi_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *troupeauxx, *treeview1;

troupeauxx=lookup_widget(objet, "troupeauxx");
gtk_widget_destroy(troupeauxx);
troupeauxx=create_troupeauxx();
gtk_widget_show(troupeauxx);

treeview1=lookup_widget(troupeauxx,"treeview1");
aff_brebi(treeview1);
}


void
on_aff_troupeaux_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *troupeauxx, *treeview1;

troupeauxx=lookup_widget(objet, "troupeauxx");
gtk_widget_destroy(troupeauxx);
troupeauxx=create_troupeauxx();
gtk_widget_show(troupeauxx);

treeview1=lookup_widget(troupeauxx,"treeview1");
aff_tr(treeview1);
}


///////////////////////////////////////////////




//******Amira*****///

GtkWidget *eqag;
GtkWidget *treeaff;
GtkWidget *eg;
GtkWidget *output;

void
on_actaff_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
eqag=lookup_widget(objet, "equipement");
gtk_widget_destroy(eqag);
eqag=create_equipement();
gtk_widget_show(eqag);
}


void
on_marq_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_aff_clicked                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
eqag=lookup_widget(objet_graphique,"equipement");
eg=lookup_widget(eqag,"eg");
treeaff=lookup_widget(eqag,"treeaff");
afficher_equipement(treeaff);
}

void
on_defec_clicked                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
eqag=lookup_widget(objet_graphique,"equipement");
eg=lookup_widget(eqag,"eg");
treeaff=lookup_widget(eqag,"treeaff");
afficher_defectueux(treeaff);
}


void
on_ajact_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
eqag=lookup_widget(objet, "equipement");
gtk_widget_destroy(eqag);
eqag=create_equipement();
gtk_widget_show(eqag);
}


void
on_ajaj_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
equipement e;

GtkWidget *ref, *nom, *marque, *jour, *mois, *annee, *jourm, *moism, *anneem, *bon, *def;

eqag=lookup_widget(objet, "equipement");

ref=lookup_widget(objet, "eajref");
nom=lookup_widget(objet, "eajn");
marque=lookup_widget(objet, "eajm");
jour=lookup_widget(objet, "spinbuttonajaj");
mois=lookup_widget(objet, "spinbuttonajam");
annee=lookup_widget(objet, "spinbuttonajaa");
jourm=lookup_widget(objet, "spinbuttonajmj");
moism=lookup_widget(objet, "spinbuttonajmm");
anneem=lookup_widget(objet, "spinbuttonajma");
bon=lookup_widget(objet, "radiobuttonajeb");
def=lookup_widget(objet, "radiobuttonajed");

strcpy(e.ref,gtk_entry_get_text(GTK_ENTRY(ref)));
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(e.marque,gtk_entry_get_text(GTK_ENTRY(marque)));

e.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
e.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
e.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
e.jourm=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourm));
e.moism=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moism));
e.anneem=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneem));

if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(bon)))
	{strcpy(e.etat,"bonne_etat");}
else	{strcpy(e.etat,"defectueux");}

ajouter_equipement(e);
}


void
on_mschr_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *emsref, *nom, *marque, *jour, *mois, *annee, *jourm, *moism, *anneem, *etat;
  equipement e;
  char ref[9] ;
 

  
  emsref=lookup_widget(objet, "emsref");
  strcpy(ref,gtk_entry_get_text(GTK_ENTRY(emsref)));
  
  e=rechercher_eq(ref);

  FILE* f;
  f=fopen("equip.txt","r");
 
  nom=lookup_widget (objet,"emsn");
  marque=lookup_widget (objet,"emsm");
  jour=lookup_widget (objet,"spinbuttonmsaj");
  mois=lookup_widget (objet,"spinbuttonmsam");
  annee=lookup_widget (objet,"spinbuttonmsaa");
  jourm=lookup_widget (objet,"spinbuttonmsmj");
  moism=lookup_widget (objet,"spinbuttonmsmm");
  anneem=lookup_widget (objet,"spinbuttonmsma");
  etat=lookup_widget (objet,"emse");
  gtk_entry_set_text (GTK_ENTRY(emsref),e.ref);
  gtk_entry_set_text (GTK_ENTRY(nom),e.nom);
  gtk_entry_set_text (GTK_ENTRY(marque),e.marque);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(jour),e.jour);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(mois),e.mois);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(annee),e.annee);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(jourm),e.jourm);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(moism),e.moism);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(anneem),e.anneem);
  gtk_entry_set_text (GTK_ENTRY(etat),e.etat);
  
  
  

  
  fclose(f);
}


void
on_msmod_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *emsref, *nom, *marque, *jour, *mois, *annee, *jourm, *moism, *anneem, *etat;
  equipement e1;
  char ref[9] ;
 

  
  emsref=lookup_widget(objet, "emsref");
  strcpy(ref,gtk_entry_get_text(GTK_ENTRY(emsref)));
  
  e1=rechercher_eq(ref);

  FILE* f;
  f=fopen("equip.txt","r");
 
  nom=lookup_widget (objet,"emsn");
  marque=lookup_widget (objet,"emsm");
  jour=lookup_widget (objet,"spinbuttonmsaj");
  mois=lookup_widget (objet,"spinbuttonmsam");
  annee=lookup_widget (objet,"spinbuttonmsaa");
  jourm=lookup_widget (objet,"spinbuttonmsmj");
  moism=lookup_widget (objet,"spinbuttonmsmm");
  anneem=lookup_widget (objet,"spinbuttonmsma");
  etat=lookup_widget (objet,"emse");
  
strcpy(e1.ref,gtk_entry_get_text(GTK_ENTRY(emsref)));
strcpy(e1.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(e1.marque,gtk_entry_get_text(GTK_ENTRY(marque)));
strcpy(e1.etat,gtk_entry_get_text(GTK_ENTRY(etat)));



e1.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
e1.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
e1.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
e1.jourm=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourm));
e1.moism=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moism));
e1.anneem=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneem));




  modifier_equipement(e1);
  fclose(f);
}


void
on_mssup_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *nom, *emsref, *marque, *jour, *mois, *annee, *jourm, *moism, *anneem, *etat, *outpout;
  equipement e;
char ref[9];
int suppri;
  FILE* f;

  emsref=lookup_widget(objet, "emsref");
  strcpy(ref,gtk_entry_get_text(GTK_ENTRY(emsref)));
   
   outpout=lookup_widget (objet,"err");
   suppri=supprimer_equipement(e,ref);
  if (suppri==1)
   {
  gtk_label_set_text (GTK_LABEL(outpout),"equipement supprimé");
	printf("equipement supprimé");
   }

}


void
on_msact_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
eqag=lookup_widget(objet, "equipement");
gtk_widget_destroy(eqag);
eqag=create_equipement();
gtk_widget_show(eqag);
}


void
on_buttoneqtot_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	char labelnbtot[10];
	int nbrt;
	GtkWidget *sortie;
	sortie=lookup_widget(objet,"labelnbtot");

	equipement e ;	

	eqag=lookup_widget(objet, "equipement");
	
	nbrt=toteq();
	sprintf(labelnbtot,"%d", nbrt);

	GdkColor color;
	gdk_color_parse("blue",&color);
	gtk_widget_modify_fg(sortie,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie),labelnbtot);
}


void
on_buttondefftot_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
	char labelnbdeff[10];
	int nbrtd;
	GtkWidget *sortie;
	sortie=lookup_widget(objet,"labelnbdeff");

	equipement e ;	

	eqag=lookup_widget(objet, "equipement");
	
	nbrtd=nbrdeff();
	sprintf(labelnbdeff,"%d", nbrtd);

	GdkColor color;
	gdk_color_parse("blue",&color);
	gtk_widget_modify_fg(sortie,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie), labelnbdeff);

}


///////////////////////////////////

//************Amine***********

void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{


	GtkTreeIter iter;
	gchar* marque ;
	gchar* type;
	gchar* valeur;	
	gchar* id;
	
	capteur capt;
	
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	
	if(gtk_tree_model_get_iter(model,&iter,path)){
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&marque,1,&id,2,&type,3,&valeur,-1);
		strcpy(capt.marque,marque);
		strcpy(capt.id,id);
		strcpy(capt.type,type);
		strcpy(capt.valeur,valeur);
		
		supp_capt(capt);
		
		aff_capt(treeview);
		
	
	}

}

void
on_supprimer_capt_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{


    GtkWidget *fenetre_afficher,*treeview3;
	GtkTreeSelection *selection ;
	GtkTreeModel *model;
	GtkTreeIter iter;
	
	gchar* marque ;
	gchar* type;
	gchar* valeur;	
	gchar* id;
	
	capteur capt;

	fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
	treeview3=lookup_widget(fenetre_afficher,"treeview3");
	selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview3));
	
	if(gtk_tree_selection_get_selected(selection,&model,&iter)) {
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&marque,1,&id,2,&type,3,&valeur,-1);
		strcpy(capt.marque,marque);
		strcpy(capt.id,id);
		strcpy(capt.type,type);
		strcpy(capt.valeur,valeur);
		fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
		gtk_widget_destroy(fenetre_afficher);
		fenetre_afficher=create_fenetre_afficher();
		gtk_widget_show(fenetre_afficher);
		treeview3=lookup_widget(fenetre_afficher,"treeview3");
		supp_capt(capt);
		aff_capt(treeview3);
		
	
	}

}


void
on_modifier_capt_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{

	GtkWidget *fenetre_afficher,*fenetre_modifier,*treeview3;
	GtkTreeSelection *selection ;
	GtkTreeModel *model;
	GtkTreeIter iter;
	GtkWidget *input2,*input4,*JOUR,*MOIS,*ANNEE,*marquecp,*typecp;
	GtkToggleButton *togglebutton;	

	gchar* marque ;
	gchar* type;
	gchar* valeur;	
	gchar* id;
	int jouri,moisi,anneei;

	capteur capt_modif;


        fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
	treeview3=lookup_widget(fenetre_afficher,"treeview3");
	selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview3));

	if(gtk_tree_selection_get_selected(selection,&model,&iter)) {
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&marque,1,&id,2,&type,3,&valeur,-1);
		strcpy(capt_modif.marque,marque);
		strcpy(capt_modif.id,id);
		strcpy(capt_modif.type,type);
		strcpy(capt_modif.valeur,valeur);
	}


	spin_button_get_val(capt_modif,&jouri,&moisi,&anneei);

	capt_modif.date_capt.jour=jouri;
	capt_modif.date_capt.mois=moisi;
	capt_modif.date_capt.annee=anneei;



	gtk_widget_destroy(fenetre_afficher);
	fenetre_modifier=create_fenetre_modifier();
	gtk_widget_show(fenetre_modifier);

	input2=lookup_widget(fenetre_modifier,"id_modf1");
	input4=lookup_widget(fenetre_modifier,"v_modf1");
	
	JOUR=lookup_widget(fenetre_modifier,"spinbutton1");
	MOIS=lookup_widget(fenetre_modifier,"spinbutton2");
	ANNEE=lookup_widget(fenetre_modifier,"spinbutton3");

	if(j==1){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(togglebutton),TRUE);
	}
	else if(j==2){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(togglebutton),TRUE);
	}
	else if(j==3){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(togglebutton),TRUE);
	}
	
	gtk_entry_set_text(GTK_ENTRY(input2),capt_modif.id);
	if(k==1){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(togglebutton),TRUE);
	}
	else if(k==2){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(togglebutton),TRUE);
	}
	else if(k==3){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(togglebutton),TRUE);
	}
	gtk_entry_set_text(GTK_ENTRY(input4),capt_modif.valeur);
	
	gtk_spin_button_set_value(JOUR,capt_modif.date_capt.jour);
	gtk_spin_button_set_value(MOIS,capt_modif.date_capt.mois);
	gtk_spin_button_set_value(ANNEE,capt_modif.date_capt.annee);
	
	marquecp=lookup_widget(fenetre_modifier,"labelm");
	typecp=lookup_widget(fenetre_modifier,"labelt");



	if(strcmp(marque,"A")==0){

		GdkColor color;
		gdk_color_parse("gold",&color);
		gtk_widget_modify_fg(marquecp,GTK_STATE_NORMAL,&color);
		gtk_label_set_text(GTK_LABEL(marquecp),"(Marque A)");
	}
	
	if(strcmp(marque,"B")==0){

		GdkColor color;
		gdk_color_parse("gold",&color);
		gtk_widget_modify_fg(marquecp,GTK_STATE_NORMAL,&color);
		gtk_label_set_text(GTK_LABEL(marquecp),"(Marque B)");
	}
	
	if(strcmp(marque,"C")==0){

		GdkColor color;
		gdk_color_parse("gold",&color);
		gtk_widget_modify_fg(marquecp,GTK_STATE_NORMAL,&color);
		gtk_label_set_text(GTK_LABEL(marquecp),"(Marque C)");
	}

	if(strcmp(type,"Temp")==0){

		GdkColor color;
		gdk_color_parse("gold",&color);
		gtk_widget_modify_fg(typecp,GTK_STATE_NORMAL,&color);
		gtk_label_set_text(GTK_LABEL(typecp),"(Temperature)");
	}

	if(strcmp(type,"Humd")==0){

		GdkColor color;
		gdk_color_parse("gold",&color);
		gtk_widget_modify_fg(typecp,GTK_STATE_NORMAL,&color);
		gtk_label_set_text(GTK_LABEL(typecp),"(Humidite)");
	}

	if(strcmp(type,"Niv")==0){

		GdkColor color;
		gdk_color_parse("gold",&color);
		gtk_widget_modify_fg(typecp,GTK_STATE_NORMAL,&color);
		gtk_label_set_text(GTK_LABEL(typecp),"(Niveau)");
	}

}


void
on_ajouter_capt_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{



	GtkWidget *fenetre_ajouter1,*fenetre_afficher;
	fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
	gtk_widget_destroy(fenetre_afficher);
	fenetre_ajouter1=create_fenetre_ajouter1();
	gtk_widget_show(fenetre_ajouter1);
	
}







void
on_confirmer2_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{

	capteur capt;
	GtkWidget *fenetre_supprimer;
	GtkWidget *fenetre_afficher;
	GtkWidget *treeview3;
	GtkWidget *input1;


	
	fenetre_supprimer=lookup_widget(objet,"fenetre_supprimer");
	

	input1=lookup_widget(objet,"id_supp");

	strcpy(capt.id,gtk_entry_get_text(GTK_ENTRY(input1)));

	supp_capt(capt);

	gtk_widget_destroy(fenetre_supprimer);
	fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
	fenetre_afficher=create_fenetre_afficher();
		
	
	gtk_widget_show(fenetre_afficher);
	
	treeview3=lookup_widget(fenetre_afficher,"treeview3");
	
	aff_capt(treeview3);		


}


void
on_retourner2_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{

	GtkWidget *fenetre_supprimer,*fenetre_afficher,*treeview3;

	fenetre_supprimer=lookup_widget(objet,"fenetre_supprimer");

	gtk_widget_destroy(fenetre_supprimer);
	fenetre_afficher=create_fenetre_afficher();
	gtk_widget_show(fenetre_afficher);

	treeview3=lookup_widget(fenetre_afficher,"treeview3");
	
	aff_capt(treeview3);


}




void
on_rechercher_capt_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{

	GtkWidget *fenetre_rechercher,*fenetre_afficher,*fenetre_alert_rech,*treeview3,*input;
	input=lookup_widget(objet,"id_rech");
	char id[10];
	int val;

	strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));

	fenetre_afficher=lookup_widget(objet,"fenetre_afficher");


	treeview3=lookup_widget(fenetre_afficher,"treeview3");
	rech_capt(id,treeview3,&val);
	
	if(val==0){
		fenetre_alert_rech=lookup_widget(objet,"fenetre_alert_rech");
		fenetre_alert_rech=create_fenetre_alert_rech();
		gtk_widget_show(fenetre_alert_rech);
	}
	


}


void
on_retourner5_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{

	GtkWidget *fenetre_rechercher,*fenetre_afficher,*treeview3;

	fenetre_rechercher=lookup_widget(objet,"fenetre_rechercher");

	gtk_widget_destroy(fenetre_rechercher);
	fenetre_afficher=create_fenetre_afficher();
	gtk_widget_show(fenetre_afficher);

	treeview3=lookup_widget(fenetre_afficher,"treeview3");
	
	aff_capt(treeview3);


}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		j=1;
	}


}


void
on_confirmer5_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{


	capteur capt;
	GtkWidget *fenetre_ajouter1;
	GtkWidget *fenetre_afficher,*fenetre_alert_id,*fenetre_alert_val,*fenetre_alert_idc;
	GtkWidget *treeview3;
	
	GtkWidget *input2,*input4;
	GtkWidget *jour,*mois,*annee;
	
	int trouve1=0,trouve2=0,trouve3=0;

	
	fenetre_ajouter1=lookup_widget(objet,"fenetre_ajouter1");
	
	
	input2=lookup_widget(objet,"id_ajt");
	input4=lookup_widget(objet,"v_ajt");

	jour=lookup_widget(objet,"jourcp");
	mois=lookup_widget(objet,"moiscp");
	annee=lookup_widget(objet,"anneecp");


	capt.date_capt.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
	capt.date_capt.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	capt.date_capt.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	

	if(j==1)
		strcpy(capt.marque,"A");
	else if(j==2)
		strcpy(capt.marque,"B");
	else if(j==3)
		strcpy(capt.marque,"C");

	strcpy(capt.id,gtk_entry_get_text(GTK_ENTRY(input2)));

	if(k==1)
		strcpy(capt.type,"Temp");
	else if(k==2)
		strcpy(capt.type,"Humd");
	else if(k==3)
		strcpy(capt.type,"Niv");

	strcpy(capt.valeur,gtk_entry_get_text(GTK_ENTRY(input4)));
	
	trouve3=test_val(capt.id);
	trouve1=test_id(capt);
	trouve2=test_val(capt.valeur);
	if(trouve1==1){
		fenetre_alert_idc=lookup_widget(objet,"fenetre_alert_idc");
		fenetre_alert_idc=create_fenetre_alert_idc();
		gtk_widget_show(fenetre_alert_idc);
	
	}
	else if(trouve2==1){
		fenetre_alert_val=lookup_widget(objet,"fenetre_alert_val");
		fenetre_alert_val=create_fenetre_alert_val();
		gtk_widget_show(fenetre_alert_val);
	}
	else if(trouve3==1){
		fenetre_alert_id=lookup_widget(objet,"fenetre_alert_id");
		fenetre_alert_id=create_fenetre_alert_id();
		gtk_widget_show(fenetre_alert_id);
	
	}
	else{
		ajt_capt(capt);

		gtk_widget_destroy(fenetre_ajouter1);
		fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
		fenetre_afficher=create_fenetre_afficher();
		
		gtk_widget_show(fenetre_afficher);
	
	
	
		treeview3=lookup_widget(fenetre_afficher,"treeview3");
	
		aff_capt(treeview3);			
		
	}
	

}


void
on_retourner6_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{

	GtkWidget *fenetre_ajouter1,*fenetre_afficher,*treeview3;

	fenetre_ajouter1=lookup_widget(objet,"fenetre_ajouter1");

	gtk_widget_destroy(fenetre_ajouter1);
	fenetre_afficher=create_fenetre_afficher();
	gtk_widget_show(fenetre_afficher);

	treeview3=lookup_widget(fenetre_afficher,"treeview3");
	
	aff_capt(treeview3);


}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		j=2;
	}


}


void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		j=3;
	}


}


void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		k=1;
	}


}


void
on_radiobutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		k=2;
	}

}


void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		k=3;
	}


}


void
on_radiobutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		l=1;
	}

}


void
on_radiobutton8_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		l=2;
	}

}


void
on_radiobutton9_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		l=3;
	}

}


void
on_radiobutton10_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		w=1;
	}

}


void
on_radiobutton11_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		w=2;
	}

}


void
on_radiobutton12_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		w=3;
	}

}


void
on_confirmer6_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{

	capteur capt;
	GtkWidget *fenetre_modifier;
	GtkWidget *fenetre_afficher,*fenetre_alert_id,*fenetre_alert_val,*fenetre_alert_idc;
	GtkWidget *treeview3;
	
	GtkWidget *input2,*input4;
	GtkWidget *jour,*mois,*annee;

	int trouve1=0,trouve2=0,trouve3=0;
	
	fenetre_modifier=lookup_widget(objet,"fenetre_modifier");
	

	
	input2=lookup_widget(objet,"id_modf1");
	input4=lookup_widget(objet,"v_modf1");

	jour=lookup_widget(objet,"spinbutton1");
	mois=lookup_widget(objet,"spinbutton2");
	annee=lookup_widget(objet,"spinbutton3");

	capt.date_capt.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
	capt.date_capt.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	capt.date_capt.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

	
	strcpy(capt.id,gtk_entry_get_text(GTK_ENTRY(input2)));

	if(l==1)
		strcpy(capt.marque,"A");
	else if(l==2)
		strcpy(capt.marque,"B");
	else if(l==3)
		strcpy(capt.marque,"C");

	

	if(w==1)
		strcpy(capt.type,"Temp");
	else if(w==2)
		strcpy(capt.type,"Humd");
	else if(w==3)
		strcpy(capt.type,"Niv");

	strcpy(capt.valeur,gtk_entry_get_text(GTK_ENTRY(input4)));

	trouve3=test_val(capt.id);
	trouve1=test_id(capt);
	trouve2=test_val(capt.valeur);
	/*if(trouve1==1){
		fenetre_alert_idc=lookup_widget(objet,"fenetre_alert_idc");
		fenetre_alert_idc=create_fenetre_alert_idc();
		gtk_widget_show(fenetre_alert_idc);
	
	}*/
	if(trouve2==1){
		fenetre_alert_val=lookup_widget(objet,"fenetre_alert_val");
		fenetre_alert_val=create_fenetre_alert_val();
		gtk_widget_show(fenetre_alert_val);
	}
	else if(trouve3==1){
		fenetre_alert_id=lookup_widget(objet,"fenetre_alert_id");
		fenetre_alert_id=create_fenetre_alert_id();
		gtk_widget_show(fenetre_alert_id);
	
	}
	else{

		modf_capt(capt);

		gtk_widget_destroy(fenetre_modifier);
		fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
		fenetre_afficher=create_fenetre_afficher();
		
		gtk_widget_show(fenetre_afficher);
	
	
	
		treeview3=lookup_widget(fenetre_afficher,"treeview3");
	
		aff_capt(treeview3);	


	}
}


void
on_retourner7_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data)
{

	GtkWidget *fenetre_modifier,*fenetre_afficher,*treeview3;

	fenetre_modifier=lookup_widget(objet,"fenetre_modifier");

	gtk_widget_destroy(fenetre_modifier);
	fenetre_afficher=create_fenetre_afficher();
	gtk_widget_show(fenetre_afficher);

	treeview3=lookup_widget(fenetre_afficher,"treeview3");
	
	aff_capt(treeview3);


}


void
on_retourner8_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	
	GtkWidget *fenetre_afficher;	
	GtkWidget *users;

	fenetre_afficher = lookup_widget(objet,"fenetre_afficher");
	gtk_widget_destroy(fenetre_afficher);

	
	users = lookup_widget(objet, "users");
	users = create_users();
	gtk_widget_show(users);


}


void
on_refrecher_capt_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
	
	


	capteur capt;
	GtkWidget *output1,*output2,*output3,*output4;
	int kr,a,b,c;
	char text1[50];
	char text2[50];
	char text3[50];
	char text4[50];

	
	output1 = lookup_widget(objet,"label_1");
	output2 = lookup_widget(objet,"label_2");
	output3 = lookup_widget(objet,"label_3");
	output4 = lookup_widget(objet,"label_4");

	kr=num_capt_alarm(capt);
	marq_capt_defect(capt,&a,&b,&c);
	
	sprintf(text1,"%d\n",kr);
	sprintf(text2,"%d\n",a);
	sprintf(text3,"%d\n",b);
	sprintf(text4,"%d\n",c);
	
	GdkColor color1;
	gdk_color_parse("red",&color1);
	gtk_widget_modify_fg(output1,GTK_STATE_NORMAL,&color1);
	gtk_label_set_text(GTK_LABEL(output1),text1);

	GdkColor color2;
	gdk_color_parse("red",&color2);
	gtk_widget_modify_fg(output2,GTK_STATE_NORMAL,&color2);
	gtk_label_set_text(GTK_LABEL(output2),text2);
			
	GdkColor color3;
	gdk_color_parse("red",&color3);
	gtk_widget_modify_fg(output3,GTK_STATE_NORMAL,&color3);
	gtk_label_set_text(GTK_LABEL(output3),text3);

	GdkColor color4;
	gdk_color_parse("red",&color4);
	gtk_widget_modify_fg(output4,GTK_STATE_NORMAL,&color4);
	gtk_label_set_text(GTK_LABEL(output4),text4);

}


void
on_refrech_t_capt_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_afficher,*treeview3;
	
	fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
	gtk_widget_destroy(fenetre_afficher);
	fenetre_afficher=create_fenetre_afficher();
	gtk_widget_show(fenetre_afficher);

	treeview3=lookup_widget(fenetre_afficher,"treeview3");

	
	
	aff_capt(treeview3);
}


void
on_fermer_eq_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *equipement;	
	GtkWidget *users;

	equipement = lookup_widget(objet,"equipement");
	gtk_widget_destroy(equipement);

	
	users = lookup_widget(objet, "users");
	users = create_users();
	gtk_widget_show(users);
}


////////////////////////////
//**************Client*****************//


client selected_c;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_treeview5_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

	GtkTreeIter iter;
	gchar* id;
	gchar* nom;
	gchar* prenom;
	gint* jour;
	gint* mois;
	gint* annee;
	gchar* tel;
	gchar* cin;

	client c;

	GtkTreeModel *model = gtk_tree_view_get_model(treeview);

	if(gtk_tree_model_get_iter(model,&iter,path))
	{
		

	gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&id ,1,&nom, 2,&prenom, 3,&jour, 4,&mois, 5,&annee, 6,&tel,7,&cin,-1);
		
				
		strcpy(c.id,id);
		strcpy(c.nom,nom);
		strcpy(c.prenom,prenom);
		c.d.jour=*jour;
		c.d.mois=*mois;
		c.d.annee=*annee;
		strcpy(c.tel,tel);
                strcpy(c.cin,cin);
		
		sup_c(c);

		aff_c(treeview);

	}

}
	



//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_refrech_c_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
        client c;

	GtkWidget *liste_clients;
	GtkWidget *treeview5;
	GtkWidget *output;

	liste_clients=lookup_widget(objet,"liste_clients");

	treeview5 = lookup_widget(liste_clients, "treeview5");

	aff_c(treeview5);

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_supp_c_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *liste_clients, *treeview5;
	GtkTreeModel *model;
	GtkTreeIter iter;
	GtkTreeSelection *selection;

	gchar* id;
	gchar* nom;
	gchar* prenom;
	gchar* jour;
	gchar* mois;
	gchar* annee;
	gchar* tel;
        gchar* cin;

	client c;

	liste_clients= lookup_widget(objet,"liste_clients");
	treeview5=lookup_widget(liste_clients,"treeview5");
	selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview5));

	if(gtk_tree_selection_get_selected(selection,&model,&iter))
	{
	gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&id ,1,&nom, 2,&prenom, 3,&jour, 4,&mois, 5,&annee, 6,&tel,7,&cin,-1);
		
				
		strcpy(c.id,id);
		strcpy(c.nom,nom);
		strcpy(c.prenom,prenom);
		strcpy(c.jour,jour);
		strcpy(c.mois,mois);		
		strcpy(c.annee,annee);
		strcpy(c.tel,tel);
                strcpy(c.cin,cin);
		
		liste_clients= lookup_widget(objet,"liste_clients");
		gtk_widget_destroy(liste_clients);
		liste_clients= create_liste_clients();
		gtk_widget_show(liste_clients);
		treeview5=lookup_widget(liste_clients,"treeview5");
		sup_c(c);

		aff_c(treeview5);

	}

}



//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_rechercher_c_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget  *liste_clients,*chercher_c;

liste_clients=lookup_widget(objet,"liste_clients");

gtk_widget_destroy(liste_clients);

chercher_c=lookup_widget(objet,"chercher_c");
chercher_c=create_chercher_c();
gtk_widget_show(chercher_c);

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_md_c_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *liste_clients;
GtkWidget *modifier_c;

GtkWidget *treeview5;
GtkTreeSelection *selection ;
GtkTreeModel *model;
GtkTreeIter iter;
GtkWidget *button;
GSList *group;

	gchar* id;
	gchar* nom;
	gchar* prenom;
	gchar* jour;
	gchar* mois;
	gchar* annee;
	gchar* tel;
        gchar* cin;

client c_modif;
//troupeaux tr;

GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*input8,*JOUR,*MOIS,*ANNEE;


	liste_clients=lookup_widget(objet,"liste_clients");

    treeview5=lookup_widget(liste_clients,"treeview5");
    selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview5));

    if(gtk_tree_selection_get_selected(selection,&model,&iter)) {
        // Obtention des varietes de la ligne selectionnée
        gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&id ,1,&nom, 2,&prenom, 3,&jour, 4,&mois, 5,&annee, 6,&tel,7,&cin,-1);

	int jour_i,mois_i,annee_i;
	jour_i=atoi(jour);
	mois_i=atoi(mois);
	annee_i=atoi(annee);

        strcpy(c_modif.id,id);
        strcpy(c_modif.nom,nom);
        strcpy(c_modif.prenom,prenom);

	c_modif.d.jour=jour_i;
	c_modif.d.mois=mois_i;
	c_modif.d.annee=annee_i;
 	strcpy(c_modif.tel,tel);
        strcpy(c_modif.cin,cin);

}
    gtk_widget_destroy(liste_clients);

    modifier_c=create_modifier_c();
    gtk_widget_show(modifier_c);

    input1=lookup_widget(modifier_c,"id1_c1");

    input2=lookup_widget(modifier_c,"nom1");
    input3=lookup_widget(modifier_c,"prenom1");

    gtk_entry_set_text(GTK_ENTRY(input1),c_modif.id);
    gtk_entry_set_text(GTK_ENTRY(input2),c_modif.nom);
    gtk_entry_set_text(GTK_ENTRY(input3),c_modif.prenom);


    JOUR=lookup_widget(modifier_c,"jour1");
    MOIS=lookup_widget(modifier_c,"mois1");
    ANNEE=lookup_widget(modifier_c,"annee1");

   gtk_spin_button_set_value(JOUR,c_modif.d.jour);
   gtk_spin_button_set_value(MOIS,c_modif.d.mois);
   gtk_spin_button_set_value(ANNEE,c_modif.d.annee);


    input4=lookup_widget(modifier_c,"tel1");
    input5=lookup_widget(modifier_c,"cin1");

   gtk_entry_set_text(GTK_ENTRY(input4),c_modif.tel);
   gtk_entry_set_text(GTK_ENTRY(input5),c_modif.cin);


}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}*/

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_resultat_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
        GtkWidget *sortie;
	GtkWidget *liste_clients;
	char nbr_s[10];
	int nbr;
	sortie=lookup_widget(objet,"nbr_tot");

	client c;	

	liste_clients=lookup_widget(objet,"liste_clients");
	
	nbr=nombre_client();
	sprintf(nbr_s,"%d", nbr);

	GdkColor color;
	gdk_color_parse("blue",&color);
	gtk_widget_modify_fg(sortie,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie),nbr_s);

	
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_retour_c_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
        GtkWidget *liste_clients, *gestion_c,*treeview5;

	gestion_c = lookup_widget(objet,"gestion_c");
	gtk_widget_destroy(gestion_c);

	liste_clients = create_liste_clients();
	gtk_widget_show(liste_clients);

	treeview5=lookup_widget(liste_clients,"treeview5");
	
	aff_c(treeview5);

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_affichage_c_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
        GtkWidget *gestion_c;	
	GtkWidget *liste_clients;
	GtkWidget *treeview5;

	gestion_c = lookup_widget(objet,"gestion_c");
	gtk_widget_destroy(gestion_c);

	
	liste_clients = lookup_widget(objet,"liste_clients");
	liste_clients = create_liste_clients();
	gtk_widget_show(liste_clients);

	treeview5=lookup_widget(liste_clients,"treeview5");

	aff_c(treeview5);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_conf_c_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{



        GtkWidget *gestion_c;
	GtkWidget *liste_clients;
	GtkWidget *treeview5;
	client c;

	GtkWidget *jour;
	GtkWidget *mois;
	GtkWidget *annee;	

	GtkWidget *input1, *input2, *input3, *input4, *input5, *sortie;

	input1=lookup_widget(objet,"id_c");
	sortie=lookup_widget(objet,"labelajc");

	input2=lookup_widget(objet,"nom");
	input3=lookup_widget(objet,"prenom");


	strcpy(c.id,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
	

	jour = lookup_widget(objet, "jourc");
	mois = lookup_widget(objet, "moisc");
	annee = lookup_widget(objet, "anneec");

	c.d.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
	c.d.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
	c.d.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));

	input4=lookup_widget(objet,"tel");
	input5=lookup_widget(objet,"cin");
	
	strcpy(c.tel,gtk_entry_get_text(GTK_ENTRY(input4)));
        strcpy(c.cin,gtk_entry_get_text(GTK_ENTRY(input5)));

        
	char id[30];
        char nom[30];
	char prenom[30];
 	char jourr[30];
	char moiss[30];
	char anneee[30];
  	char tel[30];
        char cin[30];
        int trouve=0;
        int r=0;
//char vide[5]="";

FILE *f;
 f=fopen("client.txt","r");
    

/*
while (fscanf(f,"%s %s %s %s %s %s %s %s \n",id,nom,prenom,jourr,moiss,anneee,tel,cin)!=EOF)
{
if ((strcmp(c.id,"")==0)||(strcmp(c.nom,"")==0)||(strcmp(c.prenom,"")==0)||(strcmp(c.jourr,"")==0)||(strcmp(c.moiss,"")==0)||(strcmp(c.aneee,"")==0)||(strcmp(c.tel,"")==0)||(strcmp(c.cin,"")==0))
r=1;
}
if(r!=1)
{
       GdkColor color;
	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie),"client ajoutée avec succés ");
	ajt_c(c);
	
	aff_c(treeview1);
}
 else
{ 
        GdkColor color;
	gdk_color_parse("red",&color);
	gtk_widget_modify_fg(sortie,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie),"Veuillez remplir tous les champs! ");
	

}
*/
  
 while (fscanf(f,"%s %s %s %s %s %s %s %s \n",id,nom,prenom,jourr,moiss,anneee,tel,cin)!=EOF)
  {
    if((strcmp(id,c.id))==0)
      trouve=1;
  }
    if (trouve!=1)
	{
        GdkColor color;
	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie),"client ajoutée avec succés");
	
	ajt_c(c);
	
	aff_c(treeview5);
       }
else 
     {    
        GdkColor color;
	gdk_color_parse("red",&color);
	gtk_widget_modify_fg(sortie,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie),"client existant!");
     }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_enr_c_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
        GtkWidget *modifier_c;
	GtkWidget *liste_clients;
	GtkWidget *treeview1;
	client c;
	GtkWidget *input1, *input2, *input3, *input4, *input5, *input6, *input7,*input8,*sortie;
	//GtkWidget *jour, *mois, *annee;

	sortie=lookup_widget(objet,"labelmodc");

	input1 = lookup_widget(objet,"id1_c1");
        input2 = lookup_widget(objet, "nom1");
        input3 = lookup_widget(objet, "prenom1");

        strcpy(c.id,gtk_entry_get_text(GTK_ENTRY(input1)));
        strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
        strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));

	input4 = lookup_widget(objet, "jourc1");
	input5 = lookup_widget(objet, "moisc1");
	input6 = lookup_widget(objet, "anneec1");

	c.d.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input4));
	c.d.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input5));
	c.d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input6));

        input7 = lookup_widget(objet, "tel1");
        input8 = lookup_widget(objet, "cin1");

        strcpy(c.tel,gtk_entry_get_text(GTK_ENTRY(input7)));
        strcpy(c.cin,gtk_entry_get_text(GTK_ENTRY(input8)));

	
	modf_c(c);

	GdkColor color;
	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie),"client modifier avec succés");

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_aff_c_md_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
        GtkWidget *modifier_c;	
	GtkWidget *liste_clients;
	GtkWidget *treeview5;

	modifier_c = lookup_widget(objet,"modifier_c");
	gtk_widget_destroy(modifier_c);

	
	liste_clients = lookup_widget(objet, "liste_clients");
	liste_clients = create_liste_clients();
	gtk_widget_show(liste_clients);

	treeview5=lookup_widget(liste_clients,"treeview5");
	
	aff_c(treeview5);
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_aj_c_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *liste_clients;
	GtkWidget *gestion_c;

	liste_clients=lookup_widget(objet, "liste_clients");
	gtk_widget_destroy(liste_clients);


	gestion_c=create_gestion_c();
	gtk_widget_show(gestion_c);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_rech_c_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{

FILE *f;

f = fopen("c1.txt","r");	

        char id1[30];

	char name[30];
	char pre[30]; 
	char j[30];
	char m[30];
char a[30];
char telephone[30];
char carte[30];

	char vide[10]="";
    client c;
    GtkWidget *input1,*input2,*input3,*input4,*input5,*sortie;
    GtkWidget *chercher_c;
    sortie=lookup_widget(objet,"labelrechc");
    chercher_c = lookup_widget(objet,"chercher_c");

    input1 = lookup_widget(objet,"id2");

if(strcmp(vide,gtk_entry_get_text(GTK_ENTRY(input1)))!=0)
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(input1)));
    
    rechercher_c(c,id1,name,pre,j,m,a,telephone,carte);
    gtk_entry_set_text(GTK_ENTRY(input1),"");
    GtkWidget *treeview6;
    treeview6 = lookup_widget(objet, "treeview6");

    affichage_rechercher_c(treeview6);

	GdkColor color;
	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie),"client trouvé");


}


void
on_Client_c_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *liste_clients,*treeview5;	
	GtkWidget *work;

	work = lookup_widget(objet,"work");
	gtk_widget_destroy(work);

	
	liste_clients = lookup_widget(objet, "liste_clients");
	liste_clients = create_liste_clients();
	gtk_widget_show(liste_clients);
	treeview5=lookup_widget(liste_clients,"treeview5");
	aff_c(treeview5);
}


void
on_ferme_client_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *liste_clients;	
	GtkWidget *users;

	liste_clients = lookup_widget(objet,"liste_clients");
	gtk_widget_destroy(liste_clients);

	
	users = lookup_widget(objet, "users");
	users = create_users();
	gtk_widget_show(users);
}


void
on_rt_md_c_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *liste_clients, *modifier_c,*treeview5;

	modifier_c = lookup_widget(objet,"modifier_c");
	gtk_widget_destroy(modifier_c);

	liste_clients = create_liste_clients();
	gtk_widget_show(liste_clients);

	treeview5=lookup_widget(liste_clients,"treeview5");
	
	aff_c(treeview5);
}


void
on_return_rech1_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget  *chercher_c,*liste_clients, *treeview5;
	chercher_c=lookup_widget(objet,"chercher_c");

	gtk_widget_destroy(chercher_c);
	liste_clients=lookup_widget(objet,"liste_clients");
	liste_clients=create_liste_clients();
	gtk_widget_show(liste_clients);

	treeview5=lookup_widget(liste_clients,"treeview5");
	
	aff_c(treeview5);
}

//////////////////////////////////////
//**************Ouvrier***********//




void
on_button1_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *treeview7;

window1= lookup_widget(objet_graphique,"window1");
treeview7= lookup_widget(window1,"treeview7");
afficher(treeview7);
}


void
on_button55_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1, *input2,*input3,*input4;
GtkWidget    *window2;

int jour1,mois1,annee1;
ouvrier o;
char id[30];
char jour[30];
char mois[30];
char annee[30];
char text[100];
char text1[100];

GtkWidget    *output;


window2=create_window2();
input4=lookup_widget(objet_graphique,"entry1");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(input4)));
input1=lookup_widget(objet_graphique,"spinbutton11");
input2=lookup_widget(objet_graphique,"spinbutton22");
input3=lookup_widget(objet_graphique,"spinbutton33");
mois1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input1));
annee1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input2));
jour1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input3));

sprintf(jour,"%d",jour1);
sprintf(mois,"%d",mois1);
sprintf(annee,"%d",annee1);
strcpy(o.jour,jour);
strcpy(o.mois,mois);
strcpy(o.annee,annee);

strcpy(o.abs,y1);
strcpy(o.id,id);
ajouter(o);

if(strcmp(y1,"A")==0)
strcpy(text,"Absent");
else 
if (strcmp(y1,"P")==0)
strcpy(text,"Present");
sprintf(text1,"votre choix est: %s\n",text);
output=lookup_widget(objet_graphique,"label5");
gtk_label_set_text(GTK_LABEL(output),text1);
}


void
on_button3_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
     GtkWidget *window1; 
     GtkWidget *window3;

     window3=create_window3();
     window1= lookup_widget(objet_graphique,"window1");

     gtk_widget_hide(window1);
     gtk_widget_show(window3);
}


void
on_radiobutton111_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
strcpy(y1,"P");
}


void
on_radiobutton222_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)));
strcpy(y1,"A");
}



void
on_button2_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
    GtkWidget *window1; 
     GtkWidget *window2;

     window2=create_window2();
     window1= lookup_widget(objet_graphique,"window1");

     gtk_widget_hide(window1);
     gtk_widget_show(window2);
}


void
on_button6_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
     GtkWidget *window1; 
     GtkWidget *window2;

     window1=create_window1();
     window2= lookup_widget(objet_graphique,"window2");

     gtk_widget_hide(window2);
     gtk_widget_show(window1);
}


void
on_button4_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
/*GtkWidget *window1; 
     GtkWidget *window4;

     window4=create_window4();
     window1= lookup_widget(objet_graphique,"window1");

     gtk_widget_hide(window1);
     gtk_widget_show(window4);*/

GtkWidget *window1;
GtkWidget *window4;

GtkWidget *treeview7;
GtkTreeSelection *selection ;
GtkTreeModel *model;
GtkTreeIter iter;


	gchar* id;
	gchar* jour;
	gchar* mois;
	gchar* annee;
	gchar* abs;



	

ouvrier o;


GtkWidget *input1,*input2,*input3,*input4,*input5;


	window1=lookup_widget(objet_graphique,"window1");

    treeview7=lookup_widget(window1,"treeview7");
    selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview7));

    if(gtk_tree_selection_get_selected(selection,&model,&iter)) {
        // Obtention des varietes de la ligne selectionnée
        gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&id,1,&jour,2,&mois,3,&annee,4,&abs,-1);

	

        strcpy(o.id,id);
        strcpy(o.jour,jour);
        strcpy(o.mois,mois);
 	strcpy(o.annee,annee);
	strcpy(o.abs,abs);

	

}
    gtk_widget_destroy(window1);

    window4=create_window4();
    gtk_widget_show(window4);

    input1=lookup_widget(window4,"entry15");

    input2=lookup_widget(window4,"entry14");
    input3=lookup_widget(window4,"entry11");
    input4=lookup_widget(window4,"entry12");
    input5=lookup_widget(window4,"entry16");

    gtk_entry_set_text(GTK_ENTRY(input1),o.id);
    gtk_entry_set_text(GTK_ENTRY(input2),o.jour);
    gtk_entry_set_text(GTK_ENTRY(input3),o.mois);
    gtk_entry_set_text(GTK_ENTRY(input4),o.annee);
    gtk_entry_set_text(GTK_ENTRY(input5),o.abs);
       
}



void
on_button7_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *combobox1;
GtkWidget *output;
char text[100];
char id[30];
int x;
ouvrier o;
     
combobox1=lookup_widget(objet_graphique,"combobox1");
strcpy(id,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(o.id,id);
x=chercher(o);

if(x==1)
strcpy(text,"Ouvrier supprimé avec succées");
else 
strcpy(text,"Ouvrier n'existe pas");

output=lookup_widget(objet_graphique,"label28");
gtk_label_set_text(GTK_LABEL(output),text);
supprimer(o);
}


void
on_button8_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1; 
     GtkWidget *window3;

     window1=create_window1();
     window3= lookup_widget(objet_graphique,"window3");

     gtk_widget_hide(window3);
     gtk_widget_show(window1);
}


void
on_button9_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *combobox2;
GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *input;


char id1[30];
char jour1[30];
char mois1[30];
char annee1[30];

ouvrier o3;
int x;
char text[100];

   
combobox2=lookup_widget(objet_graphique,"combobox2");
strcpy(id1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
strcpy(o3.id,id1);

output1=lookup_widget(objet_graphique,"entry14");
strcpy(jour1,gtk_entry_get_text(GTK_ENTRY(output1)));
strcpy(o3.jour,jour1);

output2=lookup_widget(objet_graphique,"entry11");
strcpy(mois1,gtk_entry_get_text(GTK_ENTRY(output2)));
strcpy(o3.mois,mois1);

output3=lookup_widget(objet_graphique,"entry12");
strcpy(annee1,gtk_entry_get_text(GTK_ENTRY(output3)));
strcpy(o3.annee,annee1);


strcpy(o3.abs,z1);
modifier(o3);

}


void
on_button10_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1; 
     GtkWidget *window4;

     window1=create_window1();
     window4= lookup_widget(objet_graphique,"window4");

     gtk_widget_hide(window4);
     gtk_widget_show(window1);
}


void
on_button11_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1; 
     GtkWidget *window5;

     window5=create_window5();
     window1= lookup_widget(objet_graphique,"window1");

     gtk_widget_hide(window1);
     gtk_widget_show(window5);
}


void
on_button12_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

char id[30];
char mois[30];
char annee[30];
char text[100];
char text1[100];
float taux=0;

GtkWidget *output;
GtkWidget *combobox3;
GtkWidget *combobox4;
GtkWidget *combobox5;

combobox3=lookup_widget(objet_graphique,"combobox3");
strcpy(id,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox3)));


combobox4=lookup_widget(objet_graphique,"combobox4");
strcpy(mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox4)));

combobox5=lookup_widget(objet_graphique,"combobox5");
strcpy(annee,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox5)));

taux= Taux(id,mois,annee);
ajouter2(id,mois,annee,taux);
sprintf(text,"%f",taux);
sprintf(text1,"le taux d'absence est: %s % \n",text);

output=lookup_widget(objet_graphique,"label14");
gtk_label_set_text(GTK_LABEL(output),text1);
}



void
on_button13_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1; 
     GtkWidget *window5;

     window1=create_window1();
     window5= lookup_widget(objet_graphique,"window5");

     gtk_widget_hide(window5);
     gtk_widget_show(window1);
}


void
on_button14_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1; 
     GtkWidget *window6;

     window6=create_window6();
     window1= lookup_widget(objet_graphique,"window1");

     gtk_widget_hide(window1);
     gtk_widget_show(window6);
}


void
on_button15_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *combobox6,*output;
char text[100];
char text1[100];
int id;
char annee1[30];

combobox6=lookup_widget(objet_graphique,"combobox6");
strcpy(annee1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox6)));


Taux1(annee1);
id=meilleur(annee1);
sprintf(text,"%d",id);
sprintf(text1,"le meilleur ouvrier est: %s \n",text);

output=lookup_widget(objet_graphique,"label18");
gtk_label_set_text(GTK_LABEL(output),text1);

}


void
on_button16_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1; 
     GtkWidget *window6;

     window1=create_window1();
     window6= lookup_widget(objet_graphique,"window6");

     gtk_widget_hide(window6);
     gtk_widget_show(window1);
}


void
on_radiobutton444_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
strcpy(z1,"A");
}


void
on_radiobutton333_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
strcpy(z1,"P");
}


void
on_button17_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *combobox2;
GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *input;


char id1[30];
char jour1[30];
char mois1[30];
char annee1[30];

ouvrier o3;
int x;
char text[100];

   
combobox2=lookup_widget(objet_graphique,"combobox2");
strcpy(id1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
strcpy(o3.id,id1);

output1=lookup_widget(objet_graphique,"entry14");
strcpy(jour1,gtk_entry_get_text(GTK_ENTRY(output1)));
strcpy(o3.jour,jour1);

output2=lookup_widget(objet_graphique,"entry11");
strcpy(mois1,gtk_entry_get_text(GTK_ENTRY(output2)));
strcpy(o3.mois,mois1);

output3=lookup_widget(objet_graphique,"entry12");
strcpy(annee1,gtk_entry_get_text(GTK_ENTRY(output3)));
strcpy(o3.annee,annee1);

x=chercher2(o3);
if(x==1)
strcpy(text,"Cet ouvrier est present pour cette date");
else 
strcpy(text,"Cet ouvrier est absent pour cette date");

input=lookup_widget(objet_graphique,"label29");
gtk_label_set_text(GTK_LABEL(input),text);



}



void
on_ouvrier1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1,*treeview7;	
	GtkWidget *work;

	work = lookup_widget(objet,"work");
	gtk_widget_destroy(work);

	
	window1 = lookup_widget(objet, "window1");
	window1 = create_window1();
	gtk_widget_show(window1);
	treeview7=lookup_widget(window1,"treeview7");
	afficher(treeview7);
}



void
on_fermer_ouvrier_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1;	
	GtkWidget *users;

	window1 = lookup_widget(objet,"window1");
	gtk_widget_destroy(window1);

	
	users = lookup_widget(objet, "users");
	users = create_users();
	gtk_widget_show(users);
}


void
on_entrer_pr_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *input1, *input2,*work,*auth_pr,*sortie;
	int trouve;
	char log[20];
	char pw[20];
	input1=lookup_widget(objet,"entry_login_pr");
	input2=lookup_widget(objet,"entry_pw_pr");
	sortie=lookup_widget(objet,"labelpr");
	strcpy(log,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(pw,gtk_entry_get_text(GTK_ENTRY(input2)));
	trouve=verif_pr(log,pw);

	if(trouve==1)
	{
	auth_pr = lookup_widget(objet,"auth_pr");
	gtk_widget_destroy(auth_pr);

	
	work = lookup_widget(objet, "work");
	work = create_work();
	gtk_widget_show(work);

	}
	else
	{
	GdkColor color;
	gdk_color_parse("red",&color);
	gtk_widget_modify_fg(sortie,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie),"Identifiant ou Mot de passe incorrect");
	}
}


void
on_rt_pr_users_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *auth_pr;	
	GtkWidget *users;

	auth_pr = lookup_widget(objet,"auth_pr");
	gtk_widget_destroy(auth_pr);

	
	users = lookup_widget(objet, "users");
	users = create_users();
	gtk_widget_show(users);
}


void
on_button_rt_work_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *work;	
	GtkWidget *users;

	work = lookup_widget(objet,"work");
	gtk_widget_destroy(work);

	
	users = lookup_widget(objet, "users");
	users = create_users();
	gtk_widget_show(users);
}


void
on_button_brj_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *bordjlella;	
	GtkWidget *users;

	bordjlella = lookup_widget(objet,"bordjlella");
	gtk_widget_destroy(bordjlella);

	
	users = lookup_widget(objet, "users");
	users = create_users();
	gtk_widget_show(users);
}

