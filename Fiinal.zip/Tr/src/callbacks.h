#include <gtk/gtk.h>


void
on_aj_tr_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_md_tr_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supp_tr_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_conf_tr_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_conf_supp_tr_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour_tr_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour1_tr_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);


void
on_button_rechercher_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rt_md_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_enregistre_tr_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_veau_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_male_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_female_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_vivant_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_mort_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_brebi_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_brebi1_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_veau1_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_male1_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_female1_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_vivant1_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_mort1_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_refrech_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_dispo_id_tr_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_affichage_tr_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_refrech_rech_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rech_tr_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_return_rech_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_aff_tr_md_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_result_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_employe_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_administrateur_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_proprietaire_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_entrer_emp_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_inscription_emp_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_insc_aj_emp_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_auth_emp_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rt_emp_users_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_fermer_tr_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_troupeaux_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_equipment_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_capteurs_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rt_ad_users_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_inscription_ad_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_entrer_ad_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rt_auth_ad_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_insc_aj_ad_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_aff_vivant_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_aff_veau_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_aff_brebi_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_aff_troupeaux_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);


//**********Amira****************//

void
on_actaff_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_marq_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_aff_clicked                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_defec_clicked                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_ajact_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajaj_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_mschr_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_msmod_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_mssup_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_msact_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_fermer_eq_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttoneqtot_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttondefftot_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

/////////////////////////////////////

//**********Amine*********

void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_supprimer_capt_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modifier_capt_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajouter_capt_clicked                (GtkWidget       *button,
                                        gpointer         user_data);


void
on_confirmer2_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourner2_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);


void
on_rechercher_capt_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourner5_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_confirmer5_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourner6_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton8_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton9_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton10_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton11_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton12_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_confirmer6_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourner7_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourner8_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_refrecher_capt_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_refrech_t_capt_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

/////////////////////////////////
//************Client***************//



void
on_treeview5_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_refrech_c_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supp_c_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rechercher_c_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_md_c_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkButton       *objet,
                                        gpointer         user_data);

void
on_resultat_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_c_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_affichage_c_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_conf_c_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_enr_c_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_aff_c_md_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_aj_c_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rech_c_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Client_c_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ferme_client_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rt_md_c_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_return_rech1_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

//////////////////////////////////
//**********Ouvrier***********//

void
on_button1_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton111_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton222_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_button6_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button8_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button10_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button15_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button16_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_radiobutton444_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton333_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button17_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button55_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_ouvrier1_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_fermer_ouvrier_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_entrer_pr_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rt_pr_users_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_rt_work_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_brj_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);
