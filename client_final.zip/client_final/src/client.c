#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "client.h"
#include <gtk/gtk.h>

enum{
	ID,
	NOM,
	PRENOM,
	JOUR,
	MOIS,
	ANNEE,
	TEL,
        CIN,	
	COLUMNS,	
};


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void ajt_c(client c){

	FILE *f;
	f = fopen("client.txt","a+");
	if(f!=NULL){

		fprintf(f,"%s %s %s %d %d %d %s %s\n",c.id,c.nom, c.prenom,c.d.jour,c.d.mois,c.d.annee, c.tel,c.cin);

		fclose(f);
	}
}



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void affichage_rechercher(GtkWidget *liste)
{
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;

	char id[30];
        char nom[30];
	char prenom[30];
 	char jour[30];
	char mois[30];
	char annee[30];
  	char tel[30];
        char cin[30];
	store=NULL;
	FILE *f;
	store=gtk_tree_view_get_model(liste);
	if(store==NULL){

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",ID,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",PRENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	renderer = gtk_cell_renderer_text_new();
    	column = gtk_tree_view_column_new_with_attributes("jour",renderer,"text",JOUR,NULL);
    	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

    	renderer = gtk_cell_renderer_text_new();
    	column = gtk_tree_view_column_new_with_attributes("mois",renderer,"text",MOIS,NULL);
    	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

    	renderer = gtk_cell_renderer_text_new();
   	 column = gtk_tree_view_column_new_with_attributes("annee",renderer,"text",ANNEE,NULL);
   	 gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);



	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("tel",renderer,"text",TEL,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
 
 	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("cin",renderer,"text",CIN,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f = fopen("c1.txt","r");
	if(f==NULL){
		return;
	}
	else{
		f = fopen("c1.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin)!=EOF)
		{
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,ID,id,NOM,nom, PRENOM,prenom,JOUR,jour,MOIS,mois,ANNEE,annee, TEL,tel,CIN,cin,-1);
		}
		fclose(f);
		gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
		g_object_unref(store);
	}
   }
}





//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void aff_c(GtkWidget *liste)
{

	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char id[30];
    	char nom[30];
    	char prenom[30];
    	char jour[30];
	char mois[30];
	char annee[30];
    	char tel[30];
        char cin[30];
	store=NULL;
	FILE *f;
	store=gtk_tree_view_get_model(liste);
	if(store==NULL){

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",ID,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",PRENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	
	renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("jour",renderer,"text",JOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("mois",renderer,"text",MOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("annee",renderer,"text",ANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);



	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("tel",renderer,"text",TEL,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

        renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("cin",renderer,"text",CIN,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f = fopen("client.txt","r");
	if(f==NULL){
		return;
	}
	else{
		f = fopen("client.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin)!=EOF)
		{
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,ID,id,NOM,nom, PRENOM,prenom,JOUR,jour,MOIS,mois,ANNEE,annee, TEL,tel,CIN,cin,-1);

		}
		fclose(f);
		gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
		g_object_unref(store);
	}
   }
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void sup_c(client c){

	char id[30];
    	char nom[30];
    	char prenom[30];
    	char jour[30];
	char mois[30];
	char annee[30];
    	char tel[30];
        char cin[30];
	FILE *f,*t;
	f = fopen("client.txt","r");
	t = fopen("cc.txt","w");
	if(f==NULL || t==NULL){
		return;
	}
	else{
		while(fscanf(f,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin)!=EOF){

		if(strcmp(c.id,id)!=0)
			fprintf(t,"%s %s %s %s %s %s %s %s \n",id,nom,prenom,jour,mois,annee,tel,cin);
		}

		fclose(f);
		fclose(t);
		remove("client.txt");
		rename("cc.txt","client.txt");
	}	
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void modf_c(client c)
{

	char id[30];
    	char nom[30];
    	char prenom[30];
    	char jour[30];
	char mois[30];
	char annee[30];
    	char tel[30];
        char cin[30];

	FILE *f,*t;
	f = fopen("client.txt","r");
	t = fopen("cc.txt","w");

	if(f!=NULL || t!=NULL){
	while(fscanf(f,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin)!=EOF)
	{
		if(strcmp(c.id,id)==0)
		{
		fprintf(t,"%s %s %s %d %d %d %s %s\n",c.id,c.nom, c.prenom,c.d.jour,c.d.mois,c.d.annee, c.tel, c.cin);
		}
		else
		fprintf(t,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);

	}
	}
		fclose(f);
		fclose(t);
		remove("client.txt");
		rename("cc.txt","client.txt");

}



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


void rechercher(client c,char id1[30],char name[30],char pre[30],char j[30],char m[30],char a[30],char telephone[30],char carte[30])
{
	char id[30];
    	char nom[30];
    	char prenom[30];
    	char jour[30];
	char mois[30];
	char annee[30];
    	char tel[30];
        char cin[30];

FILE *f;
FILE *f1;
f = fopen("client.txt","r");
f1 = fopen("c.txt","w");

while(fscanf(f,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin)!=EOF)
	{
        if(strcmp(id,id1)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(nom,id1)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(prenom,id1)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(jour,id1)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(mois,id1)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(annee,id1)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(tel,id1)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(cin,id1)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}


        if(strcmp(id,name)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(nom,name)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(prenom,name)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(jour,name)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(mois,name)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(annee,name)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(tel,name)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(cin,name)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}


        if(strcmp(id,pre)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(nom,pre)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(prenom,pre)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(jour,pre)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(mois,pre)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(annee,pre)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(tel,pre)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(cin,pre)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}



        if(strcmp(id,j)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(nom,j)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(prenom,j)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(jour,j)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(mois,j)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(annee,j)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(tel,j)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(cin,j)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}



        if(strcmp(id,m)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(nom,m)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(prenom,m)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(jour,m)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(mois,m)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(annee,m)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(tel,m)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(cin,m)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}



        if(strcmp(id,a)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(nom,a)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(prenom,a)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(jour,a)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(mois,a)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(annee,a)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(tel,a)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(cin,a)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}


        if(strcmp(id,telephone)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(nom,telephone)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(prenom,telephone)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(jour,telephone)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(mois,telephone)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(annee,telephone)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(tel,telephone)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(cin,telephone)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}



        if(strcmp(id,carte)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(nom,carte)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(prenom,carte)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(jour,carte)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(mois,carte)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(annee,carte)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(tel,carte)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}
	else if(strcmp(cin,carte)==0)
		{
		fprintf(f1,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin);
		}









    }
fclose(f);
fclose(f1);
remove("c1.txt");
rename("c.txt","c1.txt");
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int nombre_client()
{
  FILE *f;
  FILE *b;
  
  f = fopen("client.txt","r");
  
  

  client c;
  int i=0;

 
  
  
  char id[30];
  char nom[30];
  char prenom[30];
  char jour[30];
  char mois[30];
  char annee[30];
  char tel[30];
  char cin[30];
  if(f != NULL)
	{
		
		while(fscanf(f,"%s %s %s %s %s %s %s %s\n",id,nom,prenom,jour,mois,annee,tel,cin)!=EOF)
			{
			i+=1;
			}
		
	}
	return i;
}		

