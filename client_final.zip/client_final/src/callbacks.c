#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "client.h"



client selected_c;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

	GtkTreeIter iter;
	gchar* id;
	gchar* nom;
	gchar* prenom;
	gint* jour;
	gint* mois;
	gint* annee;
	gchar* tel;
	gchar* cin;

	client c;

	GtkTreeModel *model = gtk_tree_view_get_model(treeview);

	if(gtk_tree_model_get_iter(model,&iter,path))
	{
		

	gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&id ,1,&nom, 2,&prenom, 3,&jour, 4,&mois, 5,&annee, 6,&tel,7,&cin,-1);
		
				
		strcpy(c.id,id);
		strcpy(c.nom,nom);
		strcpy(c.prenom,prenom);
		c.d.jour=*jour;
		c.d.mois=*mois;
		c.d.annee=*annee;
		strcpy(c.tel,tel);
                strcpy(c.cin,cin);
		
		sup_c(c);

		aff_c(treeview);

	}

}
	



//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_refrech_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
        client c;

	GtkWidget *liste_clients;
	GtkWidget *treeview1;
	GtkWidget *output;

	liste_clients=lookup_widget(objet,"liste_clients");

	treeview1 = lookup_widget(liste_clients, "treeview1");

	aff_c(treeview1);

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_supp_c_clicked                      (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *liste_clients, *treeview1;
	GtkTreeModel *model;
	GtkTreeIter iter;
	GtkTreeSelection *selection;

	gchar* id;
	gchar* nom;
	gchar* prenom;
	gchar* jour;
	gchar* mois;
	gchar* annee;
	gchar* tel;
        gchar* cin;

	client c;

	liste_clients= lookup_widget(objet,"liste_clients");
	treeview1=lookup_widget(liste_clients,"treeview1");
	selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview1));

	if(gtk_tree_selection_get_selected(selection,&model,&iter))
	{
	gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&id ,1,&nom, 2,&prenom, 3,&jour, 4,&mois, 5,&annee, 6,&tel,7,&cin,-1);
		
				
		strcpy(c.id,id);
		strcpy(c.nom,nom);
		strcpy(c.prenom,prenom);
		strcpy(c.jour,jour);
		strcpy(c.mois,mois);		
		strcpy(c.annee,annee);
		strcpy(c.tel,tel);
                strcpy(c.cin,cin);
		
		liste_clients= lookup_widget(objet,"liste_clients");
		gtk_widget_destroy(liste_clients);
		liste_clients= create_liste_clients();
		gtk_widget_show(liste_clients);
		treeview1=lookup_widget(liste_clients,"treeview1");
		sup_c(c);

		aff_c(treeview1);

	}

}



//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_button_rechercher_clicked           (GtkButton       *objet,
                                        gpointer         user_data)
{

GtkWidget  *liste_clients,*chercher_c;

liste_clients=lookup_widget(objet,"liste_clients");

gtk_widget_destroy(liste_clients);

chercher_c=lookup_widget(objet,"chercher_c");
chercher_c=create_chercher_c();
gtk_widget_show(chercher_c);

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_md_c_clicked                        (GtkButton       *objet,
                                        gpointer         user_data)
{

GtkWidget *liste_clients;
GtkWidget *modifier_c;

GtkWidget *treeview1;
GtkTreeSelection *selection ;
GtkTreeModel *model;
GtkTreeIter iter;
GtkWidget *button;
GSList *group;

	gchar* id;
	gchar* nom;
	gchar* prenom;
	gchar* jour;
	gchar* mois;
	gchar* annee;
	gchar* tel;
        gchar* cin;

client c_modif;

GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*input8,*JOUR,*MOIS,*ANNEE;


	liste_clients=lookup_widget(objet,"liste_clients");

    treeview1=lookup_widget(liste_clients,"treeview1");
    selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview1));

    if(gtk_tree_selection_get_selected(selection,&model,&iter)) {
        // Obtention des varietes de la ligne selectionnée
        gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&id ,1,&nom, 2,&prenom, 3,&jour, 4,&mois, 5,&annee, 6,&tel,7,&cin,-1);

	int jour_i,mois_i,annee_i;
	jour_i=atoi(jour);
	mois_i=atoi(mois);
	annee_i=atoi(annee);

        strcpy(c_modif.id,id);
        strcpy(c_modif.nom,nom);
        strcpy(c_modif.prenom,prenom);

	c_modif.d.jour=jour_i;
	c_modif.d.mois=mois_i;
	c_modif.d.annee=annee_i;
 	strcpy(c_modif.tel,tel);
        strcpy(c_modif.cin,cin);

}
    gtk_widget_destroy(liste_clients);

    modifier_c=create_modifier_c();
    gtk_widget_show(modifier_c);

    input1=lookup_widget(modifier_c,"id1_c1");

    input2=lookup_widget(modifier_c,"nom1");
    input3=lookup_widget(modifier_c,"prenom1");

    gtk_entry_set_text(GTK_ENTRY(input1),c_modif.id);
    gtk_entry_set_text(GTK_ENTRY(input2),c_modif.nom);
    gtk_entry_set_text(GTK_ENTRY(input3),c_modif.prenom);


    JOUR=lookup_widget(modifier_c,"jour1");
    MOIS=lookup_widget(modifier_c,"mois1");
    ANNEE=lookup_widget(modifier_c,"annee1");

   gtk_spin_button_set_value(JOUR,c_modif.d.jour);
   gtk_spin_button_set_value(MOIS,c_modif.d.mois);
   gtk_spin_button_set_value(ANNEE,c_modif.d.annee);


    input4=lookup_widget(modifier_c,"tel1");
    input5=lookup_widget(modifier_c,"cin1");

   gtk_entry_set_text(GTK_ENTRY(input4),c_modif.tel);
   gtk_entry_set_text(GTK_ENTRY(input5),c_modif.cin);


}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}*/

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_resultat_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
        GtkWidget *sortie;
	GtkWidget *liste_clients;
	char nbr_s[10];
	int nbr;
	sortie=lookup_widget(objet,"nbr_tot");

	client c;	

	liste_clients=lookup_widget(objet,"liste_clients");
	
	nbr=nombre_client();
	sprintf(nbr_s,"%d", nbr);

	GdkColor color;
	gdk_color_parse("blue",&color);
	gtk_widget_modify_fg(sortie,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie),nbr_s);

	
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_retour_c_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
        GtkWidget *liste_clients, *gestion_c,*treeview1;

	gestion_c = lookup_widget(objet,"gestion_c");
	gtk_widget_destroy(gestion_c);

	liste_clients = create_liste_clients();
	gtk_widget_show(liste_clients);

	treeview1=lookup_widget(liste_clients,"treeview1");
	
	aff_c(treeview1);

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_affichage_c_clicked                 (GtkButton       *objet,
                                        gpointer         user_data)
{
        GtkWidget *gestion_c;	
	GtkWidget *liste_clients;
	GtkWidget *treeview1;

	gestion_c = lookup_widget(objet,"gestion_c");
	gtk_widget_destroy(gestion_c);

	
	liste_clients = lookup_widget(objet,"liste_clients");
	liste_clients = create_liste_clients();
	gtk_widget_show(liste_clients);

	treeview1=lookup_widget(liste_clients,"treeview1");

	aff_c(treeview1);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_conf_c_clicked                      (GtkButton       *objet,
                                        gpointer         user_data)
{



        GtkWidget *gestion_c;
	GtkWidget *liste_clients;
	GtkWidget *treeview1;
	client c;

	GtkWidget *jour;
	GtkWidget *mois;
	GtkWidget *annee;	

	GtkWidget *input1, *input2, *input3, *input4, *input5, *sortie;

	input1=lookup_widget(objet,"id_c");
	sortie=lookup_widget(objet,"labelajc");

	input2=lookup_widget(objet,"nom");
	input3=lookup_widget(objet,"prenom");


	strcpy(c.id,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
	

	jour = lookup_widget(objet, "jourc");
	mois = lookup_widget(objet, "moisc");
	annee = lookup_widget(objet, "anneec");

	c.d.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
	c.d.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
	c.d.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));

	input4=lookup_widget(objet,"tel");
	input5=lookup_widget(objet,"cin");
	
	strcpy(c.tel,gtk_entry_get_text(GTK_ENTRY(input4)));
        strcpy(c.cin,gtk_entry_get_text(GTK_ENTRY(input5)));

        
	char id[30];
        char nom[30];
	char prenom[30];
 	char jourr[30];
	char moiss[30];
	char anneee[30];
  	char tel[30];
        char cin[30];
        int trouve=0;
        //int x=0;
//char vide[5]="";

 f=fopen("client.txt","r");
    FILE *f;

/*
while (fscanf(f,"%s %s %s %s %s %s %s %s \n",id,nom,prenom,jourr,moiss,anneee,tel,cin)!=EOF)
{
if ((strcmp(c.id,"")==0)||(strcmp(c.nom,"")==0)||(strcmp(c.prenom,"")==0)||(strcmp(c.jourr,"")==0)||(strcmp(c.moiss,"")==0||(strcmp(c.aneee,"")==0||(strcmp(c.tel,"")==0||(strcmp(c.cin,"")==0))
x=1;
}
if(x!=1)
{
       GdkColor color;
	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie),"client ajoutée avec succés ");
	ajt_c(c);
	
	aff_c(treeview1);
}
 else
{ 
        GdkColor color;
	gdk_color_parse("red",&color);
	gtk_widget_modify_fg(sortie,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie),"Veuillez remplir tous les champs! ");
	

}*/

  
 while (fscanf(f,"%s %s %s %s %s %s %s %s \n",id,nom,prenom,jourr,moiss,anneee,tel,cin)!=EOF)
  {
    if((strcmp(id,c.id))==0)
      trouve=1;
  }
    if (trouve!=1)
	{
        GdkColor color;
	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie),"client ajoutée avec succés");
	
	ajt_c(c);
	
	aff_c(treeview1);
       }
else 
     {    
        GdkColor color;
	gdk_color_parse("red",&color);
	gtk_widget_modify_fg(sortie,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie),"client existant!");
     }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_enr_c_clicked                       (GtkButton       *objet,
                                        gpointer         user_data)
{
        GtkWidget *modifier_c;
	GtkWidget *liste_clients;
	GtkWidget *treeview1;
	client c;
	GtkWidget *input1, *input2, *input3, *input4, *input5, *input6, *input7,*input8,*sortie;
	//GtkWidget *jour, *mois, *annee;

	sortie=lookup_widget(objet,"labelmodc");

	input1 = lookup_widget(objet,"id1_c1");
        input2 = lookup_widget(objet, "nom1");
        input3 = lookup_widget(objet, "prenom1");

        strcpy(c.id,gtk_entry_get_text(GTK_ENTRY(input1)));
        strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
        strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));

	input4 = lookup_widget(objet, "jourc1");
	input5 = lookup_widget(objet, "moisc1");
	input6 = lookup_widget(objet, "anneec1");

	c.d.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input4));
	c.d.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input5));
	c.d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input6));

        input7 = lookup_widget(objet, "tel1");
        input8 = lookup_widget(objet, "cin1");

        strcpy(c.tel,gtk_entry_get_text(GTK_ENTRY(input7)));
        strcpy(c.cin,gtk_entry_get_text(GTK_ENTRY(input8)));

	
	modf_c(c);

	GdkColor color;
	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie),"client modifier avec succés");

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_aff_c_md_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
        GtkWidget *modifier_c;	
	GtkWidget *liste_clients;
	GtkWidget *treeview1;

	modifier_c = lookup_widget(objet,"modifier_c");
	gtk_widget_destroy(modifier_c);

	
	liste_clients = lookup_widget(objet, "liste_clients");
	liste_clients = create_liste_clients();
	gtk_widget_show(liste_clients);

	treeview1=lookup_widget(liste_clients,"treeview1");
	
	aff_c(treeview1);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_rt_md_clicked                       (GtkButton       *objet,
                                        gpointer         user_data)
{
        GtkWidget *liste_clients, *modifier_c,*treeview1;

	modifier_c = lookup_widget(objet,"modifier_c");
	gtk_widget_destroy(modifier_c);

	liste_clients = create_liste_clients();
	gtk_widget_show(liste_clients);

	treeview1=lookup_widget(liste_clients,"treeview1");
	
	aff_c(treeview1);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_refrech_rech_clicked                (GtkButton       *objet,
                                        gpointer         user_data)
{ 

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_return_rech_clicked                 (GtkButton       *objet,
                                        gpointer         user_data)
{
        GtkWidget  *chercher_c,*liste_clients, *treeview1;
	chercher_c=lookup_widget(objet,"chercher_c");

	gtk_widget_destroy(chercher_c);
	liste_clients=lookup_widget(objet,"liste_clients");
	liste_clients=create_liste_clients();
	gtk_widget_show(liste_clients);

	treeview1=lookup_widget(liste_clients,"treeview1");
	
	aff_c(treeview1);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_aj_c_clicked                        (GtkButton       *objet,
                                        gpointer         user_data)
{
	GtkWidget *liste_clients;
	GtkWidget *gestion_c;

	liste_clients=lookup_widget(objet, "liste_clients");
	gtk_widget_destroy(liste_clients);


	gestion_c=create_gestion_c();
	gtk_widget_show(gestion_c);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_rech_c_clicked                      (GtkButton       *objet,
                                        gpointer         user_data)
{

FILE *f;

f = fopen("c1.txt","r");	

char id1[30];
char name[30];
char pre[30]; 
char j[30];
char m[30];
char a[30];
char telephone[30];
char carte[30];

	char vide[10]="";
    client c;
    GtkWidget *input1,*input2,*input3,*input4,*input5,*sortie;
    GtkWidget *chercher_c;
    sortie=lookup_widget(objet,"labelrechc");
    chercher_c = lookup_widget(objet,"chercher_c");

    input1 = lookup_widget(objet,"id2");

if(strcmp(vide,gtk_entry_get_text(GTK_ENTRY(input1)))!=0)
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(input1)));
    
    rechercher(c,id1,name,pre,j,m,a,telephone,carte);
  
    gtk_entry_set_text(GTK_ENTRY(input1),"");
    GtkWidget *treeview2;
    treeview2 = lookup_widget(objet, "treeview2");

    affichage_rechercher(treeview2);

	GdkColor color;
	gdk_color_parse("green",&color);
	gtk_widget_modify_fg(sortie,GTK_STATE_NORMAL,&color);
	gtk_label_set_text(GTK_LABEL(sortie),"client trouvé");


}

