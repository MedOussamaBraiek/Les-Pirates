
#ifndef CLIENT_H_INCLUDED
#define CLIENT_H_INCLUDED

#include <gtk/gtk.h>

typedef struct {
int jour;
int mois;
int annee;
}date;


typedef struct
{
    char id[30];
    char nom[30];
    char prenom[30];
    date d;
    char jour[30];
    char mois[30];
    char annee[30];
    char tel[30];
    char cin[30];

}client;

void ajt_c(client c);

void affichage_rechercher(GtkWidget *liste);

void modf_c(client c);

void sup_c(client c);

void aff_c(GtkWidget *liste);

int nombre_client();

void rechercher(client c,char id1[30],char name[30],char pre[30],char j[30],char m[30],char a[30],char telephone[30],char carte[30]);

#endif 

