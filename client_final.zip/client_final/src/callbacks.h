#include <gtk/gtk.h>


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_refrech_clicked                     (GtkButton       *objet,
                                        gpointer         user_data);

void
on_supp_c_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rechercher_clicked           (GtkButton       *objet,
                                        gpointer         user_data);

void
on_md_c_clicked                        (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_resultat_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_retour_c_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_affichage_c_clicked                 (GtkButton       *objet,
                                        gpointer         user_data);

void
on_conf_c_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_enr_c_clicked                       (GtkButton       *objet,
                                        gpointer         user_data);

void
on_aff_c_md_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_rt_md_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_refrech_rech_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_return_rech_clicked                 (GtkButton       *objet,
                                        gpointer         user_data);

void
on_aj_c_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_rech_c_clicked                      (GtkButton       *objet,
                                        gpointer         user_data);
