#include<gtk/gtk.h>

typedef struct{
	int jour;
	int mois;
	int annee;
	
}date;


typedef struct{
	char marque[10];
	char type[10];
	char valeur[10];
	char id[10];
	date date_capt;
	char jour[10];
	char mois[10];
	char annee[10];
	
}capteur;


void ajt_capt(capteur capt);
void aff_capt(GtkWidget *liste);
void supp_capt(capteur capt);
void modf_capt(capteur capt);
void rech_capt(char id1[10],GtkWidget *liste,int *trouve);
int num_capt_alarm(capteur capt);
void marq_capt_defect(capteur capt,int *t,int *h,int *e );
int test_val(char *chaine);
int test_id(capteur capt);
void spin_button_get_val(capteur capt,int *jourint,int *moisint,int *anneeint);

