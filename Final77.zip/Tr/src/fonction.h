
#ifndef FONCTION_H_INCLUDED
#define FONCTION_H_INCLUDED

#include <gtk/gtk.h>

typedef struct {
int jour;
int mois;
int annee;
}date1;


typedef struct
{
    char id[30];
    char type[30];
    char genre[30];
    //char naissance[30];
    date1 d;
	char jour[30];
	char mois[30];
	char annee[30];
    char etat[30];

} troupeaux;

void ajt_tr(troupeaux tr);

void affichage_rechercher(GtkWidget *liste);

void modf_tr(troupeaux tr);

void sup_tr(troupeaux tr);

void aff_tr(GtkWidget *liste);

//void rechercher(char id1[30],GtkWidget *liste);

int nombre_troupeaux();

int nombre_veau();

int nombre_brebi();

int troupeaux_vivant();

//void rechercher_tr(troupeaux tr,char id1[30]);

int rechercher_tr(troupeaux tr,char id1[30]);

int verif_emp(char log[20], char pw[20]);

int verif_ad(char log[20], char pw[20]);

void aff_veau(GtkWidget *liste);

void aff_brebi(GtkWidget *liste);

void aff_vivant(GtkWidget *liste);

#endif // FONCTION_H_INCLUDED

