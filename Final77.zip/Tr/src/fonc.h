#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<gtk/gtk.h>


typedef struct {
char id[30];
char jour[30];
char mois[30];
char annee[30];
char abs[30];
}ouvrier;




void ajouter(ouvrier o);
void afficher(GtkWidget *liste);
void supprimer(ouvrier o);
int chercher(ouvrier o);
void modifier(ouvrier o3);
float Taux(char id[30],char mois[30], char annee[30]);
void ajouter2(char id[30],char mois[30],char annee[30],float taux);
void Taux1(char annee1[30]);
int meilleur(char annee1[30]);
int chercher(ouvrier o);
int chercher2(ouvrier o3);
