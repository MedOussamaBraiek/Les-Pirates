#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"

troupeaux selected_tr;

int x, y, z;
int a, b, c;


//-----------Button Ajouter------------//

void
on_aj_tr_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *troupeauxx;
	GtkWidget *gestion_tr;

	troupeauxx=lookup_widget(objet, "troupeauxx");
	gtk_widget_destroy(troupeauxx);

	//inscrit_emp=lookup_widget(objet, "inscrit_emp");
	//troupeauxx=create_troupeauxx();
	gestion_tr=create_gestion_tr();
	gtk_widget_show(gestion_tr);
}


//-----------Button Modifier------------//

void
on_md_tr_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *troupeauxx;
GtkWidget *modifier_troupeaux;

GtkWidget *treeview1;
GtkTreeSelection *selection ;
GtkTreeModel *model;
GtkTreeIter iter;
GtkToggleButton *brebi1, *veau1;
GtkWidget *button;
GSList *group;

	gchar* id;
	gchar* type;
	gchar* genre;
	gchar* jour;
	gchar* mois;
	gchar* annee;
	gchar* etat;

troupeaux tr_modif;

//gint index_nom=-1;
//gint index_variete=-1;

GtkWidget *input1,*combobox1,*combobox2,*input4,*input5,*input6,*JOUR,*MOIS,*ANNEE;


	troupeauxx=lookup_widget(objet,"troupeauxx");

    treeview1=lookup_widget(troupeauxx,"treeview1");
    selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview1));

    if(gtk_tree_selection_get_selected(selection,&model,&iter)) {
        // Obtention des varietes de la ligne selectionnée
        gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&id ,1,&type, 2,&genre, 3,&jour, 4,&mois, 5,&annee, 6,&etat,-1);

        //p_modif.id=id;
        strcpy(tr_modif.id,id);
        strcpy(tr_modif.type,type);
        strcpy(tr_modif.genre,genre);
        strcpy(tr_modif.jour,jour);
        strcpy(tr_modif.mois,mois);
        strcpy(tr_modif.annee,annee);
 	strcpy(tr_modif.etat,etat);
    }

    gtk_widget_destroy(troupeauxx);

    modifier_troupeaux=create_modifier_troupeaux();
    gtk_widget_show(modifier_troupeaux);

    input1=lookup_widget(modifier_troupeaux,"id_tr1");
    /*combobox1=lookup_widget(window_modification_gp,"comboboxentry_nom_gp");
    combobox2=lookup_widget(window_modification_gp,"comboboxentry_variete_gp");
    input4=lookup_widget(window_modification_gp,"entry_quantite_gp");
    input5=lookup_widget(window_modification_gp,"entry_superficie_gp");
    input6=lookup_widget(window_modification_gp,"entry_saison_gp");*/
    JOUR=lookup_widget(modifier_troupeaux,"entry_jour1");
    MOIS=lookup_widget(modifier_troupeaux,"entry_mois1");
    ANNEE=lookup_widget(modifier_troupeaux,"entry_annee1");

	/*input4=lookup_widget(objet, "jour1");
	input5=lookup_widget(objet, "mois1");
	input6=lookup_widget(objet, "annee1");*/

    //sprintf(p_modif.s_id,"%d",p_modif.id);
    gtk_entry_set_text(GTK_ENTRY(input1),tr_modif.id);
    //gtk_combo_box_set_active(GTK_COMBO_BOX(combobox1),index_nom);
    //gtk_combo_box_set_active(GTK_COMBO_BOX(combobox2),index_variete);
    gtk_entry_set_text(GTK_ENTRY(JOUR),tr_modif.jour);
    gtk_entry_set_text(GTK_ENTRY(MOIS),tr_modif.mois);
    gtk_entry_set_text(GTK_ENTRY(ANNEE),tr_modif.annee);

	if(x==1)
		{
		group = gtk_radio_button_get_group (GTK_RADIO_BUTTON (button));
    		button = gtk_radio_button_new_with_label (group, "brebi1");
    		gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (button), TRUE);
    		gtk_box_pack_start (GTK_BOX (brebi1), button, TRUE, TRUE, 0);
    		gtk_widget_show (button); }
	else if(x==2) {
		group = gtk_radio_button_get_group (GTK_RADIO_BUTTON (button));
    		button = gtk_radio_button_new_with_label (group, "brebi");
    		gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (button), TRUE);
    		gtk_box_pack_start (GTK_BOX (veau1), button, TRUE, TRUE, 0);
    		gtk_widget_show (button);	}
		
	/*tr_modif.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input3));
	tr_modif.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input4));
	tr_modif.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input5));*/
	





/*troupeaux tr;

	GtkWidget *troupeauxx;
	GtkWidget *modifier_troupeaux;

	troupeauxx=lookup_widget(objet, "troupeauxx");
	gtk_widget_destroy(troupeauxx);

	modifier_troupeaux = create_modifier_troupeaux();
	gtk_widget_show(modifier_troupeaux);*/


/*GtkWidget *modif;
GtkWidget *window;
window= create_modifier_troupeaux();
  gtk_widget_show (window);

troupeaux tr;

GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*input8,*input9,*input10;


input1=lookup_widget(window,"id_tr");
input2=lookup_widget(window,"brebi");
input3=lookup_widget(window,"veau");
input4=lookup_widget(window,"male");
input5=lookup_widget(window,"female");
input6=lookup_widget(window, "entry_jour");
input7=lookup_widget(window, "entry_mois");
input8=lookup_widget(window, "entry_annee");
input9=lookup_widget(window, "vivant");
input10=lookup_widget(window, "mort");

gtk_entry_set_text(input1,selected_tr.id);
//gtk_entry_set_text(input2,selected_tr.type);
gtk_entry_set_text(input3,selected_tr.type);
gtk_entry_set_text(input4,selected_tr.genre);
//gtk_combo_box_set_entry_text(input5,selected_client.sexe);
//gtk_entry_set_text(input6,selected_tr.genre);
//gtk_spin_button_set_value(input7,selected_client.inscri);
gtk_entry_set_text(input6,selected_tr.jour);
gtk_entry_set_text(input7,selected_tr.mois);
gtk_entry_set_text(input8,selected_tr.annee);
//gtk_entry_set_text(input3,selected_tr.etat);
gtk_entry_set_text(input9,selected_tr.etat);*/

}


//-----------Button Supprimer------------//

void
on_supp_tr_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	/*troupeaux tr;
	//GtkWidget *input1, *input2, *input3, *input4, *input5, *input6, *input7;

	GtkWidget *troupeauxx;
	GtkWidget *gestion_tr;
	GtkWidget *supp_tr;

	troupeauxx=lookup_widget(objet, "troupeauxx");
	gtk_widget_destroy(troupeauxx);

	supp_tr = create_supp_tr();
	gtk_widget_show(supp_tr);*/

	/*GtkWidget *troupeauxx;

	troupeauxx=lookup_widget(objet,"troupeauxx");
	sup_tr(selected_tr);

	GtkWidget *tree;
	tree=lookup_widget(troupeauxx,"treeview1");
	aff_tr(tree);*/

	GtkWidget *troupeauxx, *treeview1;
	GtkTreeModel *model;
	GtkTreeIter iter;
	GtkTreeSelection *selection;

	gchar* id;
	gchar* type;
	gchar* genre;
	gchar* jour;
	gchar* mois;
	gchar* annee;
	gchar* etat;

	troupeaux tr;

	troupeauxx= lookup_widget(objet,"troupeauxx");
	treeview1=lookup_widget(troupeauxx,"treeview1");
	selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview1));

	if(gtk_tree_selection_get_selected(selection,&model,&iter))
	{
	gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&id ,1,&type, 2,&genre, 3,&jour, 4,&mois, 5,&annee, 6,&etat,-1);
		
				
		strcpy(tr.id,id);
		strcpy(tr.type,type);
		strcpy(tr.genre,genre);
		strcpy(tr.jour,jour);
		strcpy(tr.mois,mois);		
		strcpy(tr.annee,annee);
		strcpy(tr.etat,etat);
		
		troupeauxx= lookup_widget(objet,"troupeauxx");
		gtk_widget_destroy(troupeauxx);
		troupeauxx= create_troupeauxx();
		gtk_widget_show(troupeauxx);
		treeview1=lookup_widget(troupeauxx,"treeview1");
		sup_tr(tr);

		aff_tr(treeview1);

	}

}

//-----------Button Confirmer------------//


void
on_conf_tr_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *gestion_tr;
	GtkWidget *troupeauxx;
	GtkWidget *treeview1;
	troupeaux tr;

	GtkWidget *jour;
	GtkWidget *mois;
	GtkWidget *annee;	

	GtkWidget *input1, *input2, *input3, *input4; //, *input5, *input6, *input7;
	//GtkWidget *liste_emp, *inscrit_emp;

	input1=lookup_widget(objet,"id_tr");
	//input2=lookup_widget(objet,"entry_nom");
	//input3=lookup_widget(objet,"entry_prenom");
	//input4=lookup_widget(objet,"entry_naissance");
	/*input5=lookup_widget(objet,"entry_specialite");
	input6=lookup_widget(objet,"entry_numero");
	input7=lookup_widget(objet,"entry_email");*/

	strcpy(tr.id,gtk_entry_get_text(GTK_ENTRY(input1)));
	//strcpy(emp.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
	//strcpy(emp.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
	//strcpy(tr.naissance,gtk_entry_get_text(GTK_ENTRY(input4)));

	
	if(x==1)
		strcpy(tr.type,"Brebi");
	else if(x==2)
		strcpy(tr.type,"Veau");
	

	if(y==1)
		strcpy(tr.genre,"Male");
	else if(y==2)
		strcpy(tr.genre,"Female");

	jour = lookup_widget(objet, "jour");
	mois = lookup_widget(objet, "mois");
	annee = lookup_widget(objet, "annee");

	//tr.d.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
	//tr.d.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
	//tr.d.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));

	input2=lookup_widget(objet,"entry_jour");
	input3=lookup_widget(objet,"entry_mois");
	input4=lookup_widget(objet,"entry_annee");
	strcpy(tr.jour,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(tr.mois,gtk_entry_get_text(GTK_ENTRY(input3)));
	strcpy(tr.annee,gtk_entry_get_text(GTK_ENTRY(input4)));


	if(z==1)
		strcpy(tr.etat,"Vivant");
	else if(z==2)
		strcpy(tr.etat,"Mort");
	

	
	
	ajt_tr(tr);


	gestion_tr = lookup_widget(objet,"gestion_tr");
	gtk_widget_destroy(gestion_tr);

	
	troupeauxx = lookup_widget(objet,"troupeaux");
	troupeauxx = create_troupeauxx();
	gtk_widget_show(troupeauxx);

	treeview1=lookup_widget(troupeauxx,"treeview1");
	
	aff_tr(treeview1);
}



void
on_conf_supp_tr_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	/*troupeaux tr;

	GtkWidget *supp_tr;
	GtkWidget *troupeauxx;
	GtkWidget *treeview1;

	GtkWidget *input1;

	supp_tr=lookup_widget(objet,"supp_tr");

	input1=lookup_widget(objet,"id_supp");

	strcpy(tr.id,gtk_entry_get_text(GTK_ENTRY(input1)));

	sup_tr(tr);

	gtk_widget_destroy(supp_tr);

	troupeauxx=lookup_widget(objet,"troupeauxx");
	troupeauxx = create_troupeauxx();
	gtk_widget_show(troupeauxx);

	treeview1 = lookup_widget(troupeauxx, "treeview1");

	aff_tr(treeview1);*/

	/*GtkWidget *troupeauxx, *treeview1;
	GtkTreeModel *model;
	GtkTreeIter iter;
	GtkTreeSelection *selection;

	gchar* id;
	gchar* type;
	gchar* genre;
	gchar* jour;
	gchar* mois;
	gchar* annee;
	gchar* etat;

	troupeaux tr;

	troupeauxx= lookup_widget(objet,"troupeauxx");
	treeview1=lookup_widget(troupeauxx,"treeview1");
	selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview1));

	if(gtk_tree_selection_get_selected(selection,&model,&iter))
	{
	gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&id ,1,&type, 2,&genre, 3,&jour, 4,&mois, 5,&annee, 6,&etat,-1);
		
				
		strcpy(tr.id,id);
		strcpy(tr.type,type);
		strcpy(tr.genre,genre);
		strcpy(tr.jour,jour);
		strcpy(tr.mois,mois);		
		strcpy(tr.annee,annee);
		strcpy(tr.etat,etat);
		
		sup_tr(tr);

		aff_tr(treeview1);

	}*/
	
}


void
on_retour_tr_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *troupeauxx, *gestion_tr,*treeview1;

	gestion_tr = lookup_widget(objet,"gestion_tr");
	gtk_widget_destroy(gestion_tr);

	troupeauxx = create_troupeauxx();
	gtk_widget_show(troupeauxx);

	treeview1=lookup_widget(troupeauxx,"treeview1");
	
	aff_tr(treeview1);
}


void
on_retour1_tr_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *troupeauxx, *supp_tr,*treeview1;

	supp_tr = lookup_widget(objet,"supp_tr");
	gtk_widget_destroy(supp_tr);

	troupeauxx = create_troupeauxx();
	gtk_widget_show(troupeauxx);

	treeview1=lookup_widget(troupeauxx,"treeview1");
	
	aff_tr(treeview1);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	/*GtkTreeIter iter;
	gchar* id;
	gchar* type;
	gchar* genre;
	gchar* jour;
	gchar* mois;
	gchar* annee;
	gchar* etat;
	
	troupeaux tr;

	GtkTreeModel *model = gtk_tree_view_get_model(treeview);

	if(gtk_tree_model_get_iter(model,&iter,path))
	{
		

	gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&id ,1,&type, 2,&genre, 3,&jour, 4,&mois, 5,&annee, 6,&etat,-1);
		
				
		strcpy(tr.id,id);
		strcpy(tr.type,type);
		strcpy(tr.genre,genre);
		strcpy(tr.jour,jour);
		strcpy(tr.mois,mois);		
		strcpy(tr.annee,annee);
		strcpy(tr.etat,etat);
		
		sup_tr(tr);

		aff_tr(treeview);

	}*/


	
	gchar *str_data;
	GtkListStore *list_store;
	list_store=gtk_tree_view_get_model(treeview);
	GtkTreeIter iter;
	if(gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store),&iter,path))
	{
	gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,0,&str_data,-1);

	}
	strcpy(str_data,selected_tr.id);

	FILE *f;
	troupeaux tr;
	f=fopen("fichier.txt","r");
	while(!feof(f))
		{
		fscanf(f,"%s %s %s %s %s %s %s\n",tr.id,tr.type,tr.genre,tr.jour,tr.mois,tr.annee,tr.etat);
		if(strcmp(selected_tr.id,tr.id)==0){selected_tr=tr;}
		}
	fclose(f);


}


//---------Bouton Chercher----------//

void
on_button_rechercher_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *troupeauxx;
GtkWidget *input;
input= lookup_widget (objet,"id_tr_rechercher");
char id[25];

strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));


GtkWidget *treeview1;
troupeauxx=lookup_widget (objet,"troupeauxx");


treeview1=lookup_widget (troupeauxx,"treeview1");

rechercher(id,treeview1);


	/*GtkWidget *troupeauxx;
	GtkWidget *input1,*input2,*input3;
	
	char id[30];
	char type[30];
	char genre[30];
	char vide="";
	
	input1= lookup_widget (objet,"id_tr_rechercher");
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(input1)));

	input2= lookup_widget (objet,"type_tr_rechercher");
	strcpy(type,gtk_entry_get_text(GTK_ENTRY(input2)));

	input3= lookup_widget (objet,"genre_tr_rechercher");
	strcpy(genre,gtk_entry_get_text(GTK_ENTRY(input3)));


	GtkWidget *treeview1;
	troupeauxx=lookup_widget (objet,"troupeauxx");


	treeview1=lookup_widget (troupeauxx,"treeview1");

	if(strcmp(id,vide)!=0)
	rechercher(id,treeview1);
	//else
	if(strcmp(type,vide)!=0)
	rechercher(type,treeview1);
	//else
	if(strcmp(genre,vide)!=0)
	rechercher(genre,treeview1);*/
    




 /*  char id1[30];
    troupeaux tr;
    GtkWidget *input;
    GtkWidget *troupeauxx;

    troupeauxx = lookup_widget(objet,"troupeauxx");

    input = lookup_widget(objet,"combobox1");
    strcpy(id1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input)));
    
	rechercher(tr,id1);
    gtk_entry_set_text(GTK_ENTRY(input),"");
    GtkWidget *treeview1;
    treeview1 = lookup_widget(objet, "treeview1");
	//sup_tr(id1,treeview1);
    affichage_rechercher(treeview1);*/

}


void
on_rt_md_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *troupeauxx, *modifier_troupeaux,*treeview1;

	modifier_troupeaux = lookup_widget(objet,"modifier_troupeaux");
	gtk_widget_destroy(modifier_troupeaux);

	troupeauxx = create_troupeauxx();
	gtk_widget_show(troupeauxx);

	treeview1=lookup_widget(troupeauxx,"treeview1");
	
	aff_tr(treeview1);
}


void
on_enregistre_tr_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *modifier_troupeaux;
	GtkWidget *troupeauxx;
	GtkWidget *treeview1;
	troupeaux tr;
	GtkWidget *input1, *input2, *input3, *input4, *input5, *input6, *input7;
	//GtkWidget *liste_emp, *inscrit_emp;

	input1=lookup_widget(objet,"id_tr1");
	
	//input5=lookup_widget(objet,"entry_specialite1");
	

	strcpy(tr.id,gtk_entry_get_text(GTK_ENTRY(input1)));
	
	//strcpy(tr.etat,gtk_entry_get_text(GTK_ENTRY(input5)));

	if(a==1)
		strcpy(tr.type,"Brebi");
	else if(a==2)
		strcpy(tr.type,"Veau");
	

	if(b==1)
		strcpy(tr.genre,"Male");
	else if(b==2)
		strcpy(tr.genre,"Female");

	input2=lookup_widget(objet,"entry_jour");
	input3=lookup_widget(objet,"entry_mois");
	input4=lookup_widget(objet,"entry_annee");

	strcpy(tr.jour,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(tr.mois,gtk_entry_get_text(GTK_ENTRY(input3)));
	strcpy(tr.annee,gtk_entry_get_text(GTK_ENTRY(input4)));


	if(c==1)
		strcpy(tr.etat,"Vivant");
	else if(c==2)
		strcpy(tr.etat,"Mort");
	
	
	
	modf_tr(tr);


	modifier_troupeaux = lookup_widget(objet,"modifier_troupeaux");
	gtk_widget_destroy(modifier_troupeaux);

	
	troupeauxx = lookup_widget(objet, "troupeauxx");
	troupeauxx = create_troupeauxx();
	gtk_widget_show(troupeauxx);

	treeview1=lookup_widget(troupeauxx,"treeview1");
	
	aff_tr(treeview1);
}





void
on_veau_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		x=2;
	}
}


void
on_male_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		y=1;
	}
}


void
on_female_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		y=2;
	}
}


void
on_vivant_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		z=1;
	}
}


void
on_mort_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		z=2;
	}
}


void
on_brebi_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		x=1;
	}
}


void
on_brebi1_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		a=1;
	}
}

void
on_veau1_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		a=2;
	}	
}

void
on_male1_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		b=1;
	}
}

void
on_female1_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		b=2;
	}

}
void
on_vivant1_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		c=1;
	}
}

void
on_mort1_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
		c=2;
	}
}

void
on_refrech_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	troupeaux tr;

	GtkWidget *troupeauxx;
	GtkWidget *treeview1;
	GtkWidget *output;


	//gtk_widget_destroy(troupeauxx);
	troupeauxx=lookup_widget(objet,"troupeauxx");
	//troupeauxx = create_troupeauxx();
	//gtk_widget_show(troupeauxx);*/

	treeview1 = lookup_widget(troupeauxx, "treeview1");

	aff_tr(treeview1);

}

void
on_dispo_id_tr_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
    troupeaux tr;
    GtkWidget *id1;
    id1 = lookup_widget(objet, "combobox1");
    FILE *f;
    f = fopen("fichier.txt","r");
    if(f!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %s %s %s\n",tr.id,tr.type,tr.genre,tr.jour,tr.mois,tr.annee,tr.etat)!=EOF)
        {
            gtk_combo_box_append_text(GTK_COMBO_BOX(id1),_(tr.id));
        }
    }

}


void
on_affichage_tr_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_refrech_rech_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_rech_tr_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_return_rech_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}

