#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"


char y[30];
char z[30];


void
on_button1_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *treeview1;

window1= lookup_widget(objet_graphique,"window1");
treeview1= lookup_widget(window1,"treeview1");
afficher(treeview1);
}


void
on_button5_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1, *input2,*input3,*input4;
GtkWidget    *window2;

int jour1,mois1,annee1;
ouvrier o;
char id[30];
char jour[30];
char mois[30];
char annee[30];
char text[100];
char text1[100];

GtkWidget    *output;


window2=create_window2();
input4=lookup_widget(objet_graphique,"entry1");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(input4)));
input1=lookup_widget(objet_graphique,"spinbutton1");
input2=lookup_widget(objet_graphique,"spinbutton2");
input3=lookup_widget(objet_graphique,"spinbutton3");
mois1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input1));
annee1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input2));
jour1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input3));

sprintf(jour,"%d",jour1);
sprintf(mois,"%d",mois1);
sprintf(annee,"%d",annee1);
strcpy(o.jour,jour);
strcpy(o.mois,mois);
strcpy(o.annee,annee);

strcpy(o.abs,y);
strcpy(o.id,id);
ajouter(o);

if(strcmp(y,"A")==0)
strcpy(text,"Absent");
else 
if (strcmp(y,"P")==0)
strcpy(text,"Present");
sprintf(text1,"votre choix est: %s\n",text);
output=lookup_widget(objet_graphique,"label5");
gtk_label_set_text(GTK_LABEL(output),text1);
}


void
on_button3_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
     GtkWidget *window1; 
     GtkWidget *window3;

     window3=create_window3();
     window1= lookup_widget(objet_graphique,"window1");

     gtk_widget_hide(window1);
     gtk_widget_show(window3);
}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
strcpy(y,"P");
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)));
strcpy(y,"A");
}



void
on_button2_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
    GtkWidget *window1; 
     GtkWidget *window2;

     window2=create_window2();
     window1= lookup_widget(objet_graphique,"window1");

     gtk_widget_hide(window1);
     gtk_widget_show(window2);
}


void
on_button6_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
     GtkWidget *window1; 
     GtkWidget *window2;

     window1=create_window1();
     window2= lookup_widget(objet_graphique,"window2");

     gtk_widget_hide(window2);
     gtk_widget_show(window1);
}


void
on_button4_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window4;

GtkWidget *treeview1;
GtkTreeSelection *selection ;
GtkTreeModel *model;
GtkTreeIter iter;


	gchar* id;
	gchar* jour;
	gchar* mois;
	gchar* annee;
	gchar* abs;



	

ouvrier o;


GtkWidget *input1,*input2,*input3,*input4,*input5;


	window1=lookup_widget(objet_graphique,"window1");

    treeview1=lookup_widget(window1,"treeview1");
    selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview1));

    if(gtk_tree_selection_get_selected(selection,&model,&iter)) {
        // Obtention des varietes de la ligne selectionnée
        gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&id,1,&jour,2,&mois,3,&annee,4,&abs,-1);

	

        strcpy(o.id,id);
        strcpy(o.jour,jour);
        strcpy(o.mois,mois);
 	strcpy(o.annee,annee);
	strcpy(o.abs,abs);

	

}
    gtk_widget_destroy(window1);

    window4=create_window4();
    gtk_widget_show(window4);

    input1=lookup_widget(window4,"entry15");

    input2=lookup_widget(window4,"entry14");
    input3=lookup_widget(window4,"entry11");
    input4=lookup_widget(window4,"entry12");
    input5=lookup_widget(window4,"entry16");

    gtk_entry_set_text(GTK_ENTRY(input1),o.id);
    gtk_entry_set_text(GTK_ENTRY(input2),o.jour);
    gtk_entry_set_text(GTK_ENTRY(input3),o.mois);
    gtk_entry_set_text(GTK_ENTRY(input4),o.annee);
    gtk_entry_set_text(GTK_ENTRY(input5),o.abs);
       
}



void
on_button7_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *combobox1;
GtkWidget *output;
char text[100];
char id[30];
int x;
ouvrier o;
     
combobox1=lookup_widget(objet_graphique,"combobox1");
strcpy(id,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(o.id,id);
x=chercher(o);

if(x==1)
strcpy(text,"Ouvrier supprimé avec succées");
else 
strcpy(text,"Ouvrier n'existe pas");

output=lookup_widget(objet_graphique,"label28");
gtk_label_set_text(GTK_LABEL(output),text);
supprimer(o);
}


void
on_button8_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1; 
     GtkWidget *window3;

     window1=create_window1();
     window3= lookup_widget(objet_graphique,"window3");

     gtk_widget_hide(window3);
     gtk_widget_show(window1);
}


void
on_button9_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *input;


char id1[30];
char jour1[30];
char mois1[30];
char annee1[30];

ouvrier o3;

  
output1=lookup_widget(objet_graphique,"entry15");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(output1)));
strcpy(o3.id,id1);

output1=lookup_widget(objet_graphique,"entry14");
strcpy(jour1,gtk_entry_get_text(GTK_ENTRY(output1)));
strcpy(o3.jour,jour1);

output2=lookup_widget(objet_graphique,"entry11");
strcpy(mois1,gtk_entry_get_text(GTK_ENTRY(output2)));
strcpy(o3.mois,mois1);

output3=lookup_widget(objet_graphique,"entry12");
strcpy(annee1,gtk_entry_get_text(GTK_ENTRY(output3)));
strcpy(o3.annee,annee1);


strcpy(o3.abs,z);
modifier(o3);

}


void
on_button10_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1; 
     GtkWidget *window4;

     window1=create_window1();
     window4= lookup_widget(objet_graphique,"window4");

     gtk_widget_hide(window4);
     gtk_widget_show(window1);
}


void
on_button11_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1; 
     GtkWidget *window5;

     window5=create_window5();
     window1= lookup_widget(objet_graphique,"window1");

     gtk_widget_hide(window1);
     gtk_widget_show(window5);
}


void
on_button12_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

char id[30];
char mois[30];
char annee[30];
char text[100];
char text1[100];
float taux=0;

GtkWidget *output;
GtkWidget *combobox3;
GtkWidget *combobox4;
GtkWidget *combobox5;

combobox3=lookup_widget(objet_graphique,"combobox3");
strcpy(id,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox3)));


combobox4=lookup_widget(objet_graphique,"combobox4");
strcpy(mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox4)));

combobox5=lookup_widget(objet_graphique,"combobox5");
strcpy(annee,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox5)));

taux= Taux(id,mois,annee);
ajouter2(id,mois,annee,taux);
sprintf(text,"%f",taux);
sprintf(text1,"le taux d'absence est: %s % \n",text);

output=lookup_widget(objet_graphique,"label14");
gtk_label_set_text(GTK_LABEL(output),text1);
}



void
on_button13_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1; 
     GtkWidget *window5;

     window1=create_window1();
     window5= lookup_widget(objet_graphique,"window5");

     gtk_widget_hide(window5);
     gtk_widget_show(window1);
}


void
on_button14_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1; 
     GtkWidget *window6;

     window6=create_window6();
     window1= lookup_widget(objet_graphique,"window1");

     gtk_widget_hide(window1);
     gtk_widget_show(window6);
}


void
on_button15_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *combobox6,*output;
char text[100];
char text1[100];
int id;
char annee1[30];

combobox6=lookup_widget(objet_graphique,"combobox6");
strcpy(annee1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox6)));


Taux1(annee1);
id=meilleur(annee1);
sprintf(text,"%d",id);
sprintf(text1,"le meilleur ouvrier est: %s \n",text);

output=lookup_widget(objet_graphique,"label18");
gtk_label_set_text(GTK_LABEL(output),text1);

}


void
on_button16_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1; 
     GtkWidget *window6;

     window1=create_window1();
     window6= lookup_widget(objet_graphique,"window6");

     gtk_widget_hide(window6);
     gtk_widget_show(window1);
}


void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
strcpy(z,"A");
}


void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
strcpy(z,"P");
}


void
on_button17_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *combobox2;
GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *input;


char id1[30];
char jour1[30];
char mois1[30];
char annee1[30];

ouvrier o3;
int x;
char text[100];

   
combobox2=lookup_widget(objet_graphique,"combobox2");
strcpy(id1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
strcpy(o3.id,id1);

output1=lookup_widget(objet_graphique,"entry14");
strcpy(jour1,gtk_entry_get_text(GTK_ENTRY(output1)));
strcpy(o3.jour,jour1);

output2=lookup_widget(objet_graphique,"entry11");
strcpy(mois1,gtk_entry_get_text(GTK_ENTRY(output2)));
strcpy(o3.mois,mois1);

output3=lookup_widget(objet_graphique,"entry12");
strcpy(annee1,gtk_entry_get_text(GTK_ENTRY(output3)));
strcpy(o3.annee,annee1);

x=chercher2(o3);
if(x==1)
strcpy(text,"Cet ouvrier est present pour cette date");
else 
strcpy(text,"Cet ouvrier est absent pour cette date");

input=lookup_widget(objet_graphique,"label29");
gtk_label_set_text(GTK_LABEL(input),text);



}

