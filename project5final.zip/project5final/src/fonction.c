
#ifdef HAVE_CONFIG_H
#include<config.h>
#endif

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"fonction.h"
#include<gtk/gtk.h>


enum
{
   	ED,
        EJOUR,
	EMOIS,
	EANNEE,
	EABS,
	COLUMN,
};





void ajouter(ouvrier o)
	{
	FILE *f;
	f=fopen("users.txt","a+");
	if (f!=NULL)
	{
	fprintf(f,"%s %s %s %s %s\n",o.id,o.jour,o.mois,o.annee,o.abs);
	fclose(f);
	}
	}



void afficher(GtkWidget *liste)

	{
      	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column; 
	GtkTreeIter iter;
	GtkListStore *store;


        char id[30];
	char jour[30];
	char mois[30];
	char annee[30];	
 	char abs[30];
	store=NULL;
  	
	FILE *f;
store=gtk_tree_view_get_model(liste);
	if(store==NULL)
	{
	renderer= gtk_cell_renderer_text_new();
	column= gtk_tree_view_column_new_with_attributes("Identité",renderer,"text",ED,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);



        renderer= gtk_cell_renderer_text_new();
	column= gtk_tree_view_column_new_with_attributes("jour",renderer,"text",EJOUR,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


	renderer= gtk_cell_renderer_text_new();
	column= gtk_tree_view_column_new_with_attributes("Mois",renderer,"text",EMOIS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


	renderer= gtk_cell_renderer_text_new();
	column= gtk_tree_view_column_new_with_attributes("Annee",renderer,"text",EANNEE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


        renderer= gtk_cell_renderer_text_new();
	column= gtk_tree_view_column_new_with_attributes("Absent/Present",renderer,"text",EABS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	

   	store=gtk_list_store_new(COLUMN,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
   
	f=fopen("users.txt","r");
	if(f==NULL)
	{
	return;
	}
	else
	{
	while(fscanf(f,"%s %s %s %s %s\n",id,jour,mois,annee,abs)!=EOF)
	{
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,ED,id,EJOUR,jour,EMOIS,mois,EANNEE,annee,EABS,abs,-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
	g_object_unref(store);
	}
	}
        }




void supprimer(ouvrier o)
	{

	ouvrier o1;
	FILE *f,*g;

	f=fopen("users.txt","r");
	g=fopen("users2.txt","w");
	

	while(fscanf(f,"%s %s %s %s %s\n",o1.id,o1.jour,o1.mois,o1.annee,o1.abs)!=EOF)
	{
	if (strcmp(o1.id,o.id)!=0)
	{

	fprintf(g,"%s %s %s %s %s\n",o1.id,o1.jour,o1.mois,o1.annee,o1.abs);
	}
	}
	fclose(f);
	fclose(g);
	remove("users.txt");
	rename("users2.txt","users.txt");
	
	}



void modifier(ouvrier o3)

{
        ouvrier o1;
	FILE *f,*g;

	f=fopen("users.txt","r");
	g=fopen("users2.txt","w");
	

	while(fscanf(f,"%s %s %s %s %s\n",o1.id,o1.jour,o1.mois,o1.annee,o1.abs)!=EOF)
	{
	
        if (strcmp(o1.id,o3.id)==0&& strcmp(o1.jour,o3.jour)==0&& strcmp(o1.mois,o3.mois)==0&& strcmp(o1.annee,o3.annee)==0)

	{
        strcpy(o1.id,o3.id);
        strcpy(o1.jour,o3.jour);
	strcpy(o1.mois,o3.mois);
	strcpy(o1.annee,o3.annee);
	strcpy(o1.abs,o3.abs);

        fprintf(g,"%s %s %s %s %s\n",o1.id,o1.jour,o1.mois,o1.annee,o1.abs);
	}
        else
	fprintf(g,"%s %s %s %s %s\n",o1.id,o1.jour,o1.mois,o1.annee,o1.abs);
	
        }

	fclose(f);
	fclose(g);
	remove("users.txt");
	rename("users2.txt","users.txt");

}





float Taux(char id[30],char mois[30], char annee[30])
	{

	int nbr=0;
	float taux=0;
	ouvrier o;
	FILE *f;
	f=fopen("absenteisme.txt","r");
    	if (f!=NULL)
	{
         while(fscanf(f,"%s %s %s %s %s \n",o.id,o.jour,o.mois,o.annee,o.abs)!=EOF)
          {
           if ((strcmp(id,o.id)==0) && (strcmp(mois,o.mois)==0) &&(strcmp(annee,o.annee)==0)&& (strcmp(o.abs,"0")==0))
        	{   
    
		 nbr=nbr+1;
			
		}
          }
		taux = (((float)nbr)/30)*100;
 
	}
	fclose(f);
	return(taux);
	}



void Taux1(char annee1[30])
	{

	int nbr=0;
	float taux=0;
        int id1;
	
	FILE *f,*g;
	int id,jour,mois,abs;
	char annee[30];
	
        g=fopen("taux2.txt","a+");
    	if (g!=NULL)
	{
         for(id1=1;id1<10;id1++)
         { nbr = 0;
	f=fopen("absenteisme.txt","r");
	if (f!=NULL)
	{
         while(fscanf(f,"%d %d %d %s %d \n",&id,&jour,&mois,annee,&abs)!=EOF)
          {
           if ((id==id1) && (strcmp(annee, annee1) == 0) && (abs==0))
        
		 nbr=nbr+1; 
		
          }
		taux = (((float)nbr)/365)*100;
	        fprintf(g,"%d %f %s\n",id1, taux, annee1);
		 fclose(f);      
	} else { return;}
	}
	
	}
	
	fclose(g);
	}







void ajouter2(char id[30],char mois[30],char annee[30],float taux)
	{

	FILE *f;
	f=fopen("taux.txt","a+");
	if (f!=NULL)
	{
	fprintf(f,"%s %s %s %f\n",id,mois,annee,taux);
	fclose(f);
	}
	}






int meilleur(char annee1[30])
{
float min=0,taux;
int meilleur=0;
int id=0;
char annee[30];
FILE *f;
        

	f=fopen("taux2.txt","r");
 while(fscanf(f,"%d %f %s\n",&id,&taux,annee)!=EOF)
{           

if( id==1 && strcmp(annee,annee1)==0)
min=taux;

}
fclose(f);
  

   f=fopen("taux2.txt","r");
         while(fscanf(f,"%d %f %s\n",&id,&taux,annee)!=EOF)
          {
           
           if (strcmp(annee,annee1)==0 &&(taux<=min))
        	{
		 
                 meilleur=id;
                 min=taux;
                }
          }
fclose(f);
return meilleur;
}





int chercher(ouvrier o)
{
int x=0;
ouvrier o2;
FILE *f;

	f=fopen("users.txt","r");
	
	if(f==NULL)
	{
	return 0;
	}
	else
	{
	while(fscanf(f,"%s %s %s %s %s\n",o2.id,o2.jour,o2.mois,o2.annee,o2.abs)!=EOF)
	{
	if (strcmp(o2.id,o.id)==0)

	     return 1;
	
	}
	fclose(f);
	
	}
	return 0;
	}


int chercher2(ouvrier o3)
{
int x=0;
ouvrier o2;
FILE *f;

	f=fopen("users.txt","r");
	
	if(f==NULL)
	{
	return 0;
	}
	else
	{
	while(fscanf(f,"%s %s %s %s %s\n",o2.id,o2.jour,o2.mois,o2.annee,o2.abs)!=EOF)
	{
	if (strcmp(o2.id,o3.id)==0&& strcmp(o2.jour,o3.jour)==0&& strcmp(o2.mois,o3.mois)==0&& strcmp(o2.annee,o3.annee)==0)
      {
  
                 if(strcmp (o2.abs,"P")==0)
                   return 1;
                 else 
                  return 0;

      }
        
	
	}
	fclose(f);
	
	}
	return 0;
	}
