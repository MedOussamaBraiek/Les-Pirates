#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<gtk/gtk.h>


typedef struct {
char id[30];
char jour[30];
char mois[30];
char annee[30];
int abs;
}ouvrier;



int y=0;
void ajouter(ouvrier o);
void afficher(GtkWidget *liste);
