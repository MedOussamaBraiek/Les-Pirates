#include <gtk/gtk.h>


void
on_actaff_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_marq_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_aff_clicked                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_defec_clicked                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_ajact_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajaj_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_mschr_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_msmod_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_mssup_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_msact_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);
